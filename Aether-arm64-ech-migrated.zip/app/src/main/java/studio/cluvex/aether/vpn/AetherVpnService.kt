package studio.cluvex.aether.vpn

import android.content.Intent
import android.net.VpnService
import android.os.SystemClock
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import studio.cluvex.aether.R
import studio.cluvex.aether.core.AetherController
import studio.cluvex.aether.core.AutoCandidate
import studio.cluvex.aether.core.ChainRuntime
import studio.cluvex.aether.core.Diagnostics
import studio.cluvex.aether.core.DiagnosticsLog
import studio.cluvex.aether.core.EngineMeta
import studio.cluvex.aether.core.PortProbe
import studio.cluvex.aether.core.ProfileCodec
import studio.cluvex.aether.core.ShareBridge
import studio.cluvex.aether.core.SmartAuto
import studio.cluvex.aether.core.SstpCore
import studio.cluvex.aether.core.VpnConsent
import studio.cluvex.aether.core.auto.StrategyLadder
import studio.cluvex.aether.data.ProfileStore
import studio.cluvex.aether.data.SecretStore
import studio.cluvex.aether.model.ChainMode
import studio.cluvex.aether.model.ConnectionProfile
import studio.cluvex.aether.model.ConnectionState
import studio.cluvex.aether.model.Protocol
import studio.cluvex.aether.model.SstpConfig
import studio.cluvex.aether.model.TeamAuth
import studio.cluvex.aether.vpn.session.ChainException
import studio.cluvex.aether.vpn.session.ChainFailure
import studio.cluvex.aether.vpn.session.ConnectionPlanner
import studio.cluvex.aether.vpn.session.NativeStack
import studio.cluvex.aether.vpn.session.Readiness
import studio.cluvex.aether.vpn.session.TunnelHealth
import studio.cluvex.aether.vpn.session.TunnelWatchdog
import studio.cluvex.aether.vpn.session.VpnTunables

/**
 * The heart of the app. On connect it:
 *   1. launches the cores the chosen chain needs - the bundled `aether` engine
 *      (SOCKS5 on 127.0.0.1:1819), Psiphon, Xray and/or Tor, each dialling
 *      through the one before it,
 *   2. waits until the chain ENTRY can actually carry a connection (a real
 *      SOCKS5 CONNECT through the engine, each overlay core's own readiness
 *      signal, a warmed front) - an open port alone is not "ready",
 *   3. claims the device's VPN slot and builds the VPN TUN interface - only
 *      now, so another VPN that was carrying the device keeps doing so until
 *      Aether's own tunnel is really there (see [claimVpnSlot]),
 *   4. starts the embedded hev-socks5-tunnel core (libhev-socks5-tunnel.so) to
 *      forward all traffic through that entry - replacing v2rayNG entirely,
 *   5. supervises every core and auto-reconnects on failure.
 *
 * An SSTP session ([ChainMode.SSTP]) has a different shape, because SSTP is a
 * packet tunnel with no SOCKS entry: the PPP link comes up first, the TUN is
 * built from the address and resolvers it negotiated, and its packets are
 * pumped straight into the link (see [runSstpSession]).
 *
 * Every ladder of attempts runs under ONE session deadline (perf/fast-connect):
 * a failing session used to take the SUM of every rung's budget plus a 90 s
 * self-test per rung, which on Smart Auto was about twelve minutes.
 *
 * This class is now ONLY the session state machine: intent contract, connect
 * flow, retry/kill-switch policy and teardown ORDER. The parts it used to carry
 * itself live next door and can be read (and tested) on their own:
 *
 *  - [NativeStack]        - engine process, chain, SSTP, TUN fd, hev core, filter bridge, sharing
 *  - ChainStack           - the Psiphon / Xray / Tor hops and the DNS-capable SOCKS front
 *  - TunFactory           - the TUN builders: routing, DNS, split tunneling
 *  - [ConnectionPlanner]  - the attempt ladder for a hand-picked protocol
 *  - [Readiness]          - "does this port really carry traffic yet?"
 *  - [TunnelWatchdog]     - end-to-end health probing of a live tunnel
 *  - [VpnNotifications]   - the shade, the speed card, the tile and the widgets
 *  - [VpnTunables]        - every timeout and budget, with its reason
 */
class AetherVpnService : VpnService() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val natives = NativeStack(this)
    private val notifications = VpnNotifications(this, scope)
    private val watchdog = TunnelWatchdog()

    @Volatile
    private var runJob: Job? = null

    /**
     * The teardown coroutine of the PREVIOUS session, if one is still
     * finishing. A new connect waits for it instead of racing it (1.2.2
     * protocol-switch fix), and teardowns are chained so a second disconnect
     * can never orphan the first one's remaining work.
     */
    @Volatile
    private var stopJob: Job? = null

    /**
     * The background DNS/HTTP health check of the live session (see
     * [startHealthCheck]). Cancelled with the natives it probes.
     */
    @Volatile
    private var healthJob: Job? = null

    /**
     * Last profile the service ran with (kill-switch decisions). Written by the
     * session on an IO thread, read by `onStartCommand` on the main one - as are
     * the two jobs above, which is what the @Volatile is for.
     */
    @Volatile
    private var lastProfile: ConnectionProfile? = null

    /** True while the kill-switch blackhole TUN is up. */
    @Volatile
    private var lockdownTunActive = false

    // =============================================================== lifecycle

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // FOREGROUND-SERVICE CONTRACT - DO NOT MOVE THIS BELOW THE `when`.
        //
        // Every path into this service arrives via
        // ContextCompat.startForegroundService() (see AetherController), and the
        // platform then REQUIRES a startForeground() call within ~5 s. Miss it
        // and the service is killed with ForegroundServiceDidNotStartInTime
        // Exception - an ANR on API 26-30 and an outright crash from API 31.
        //
        // The ACTION_DISCONNECT branch used to return without ever promoting
        // the service. That is fine while a session is live (we are already
        // foreground), and a CRASH in every case where we are not: the
        // notification's Disconnect action after a failed connect, a Quick
        // Settings tap, a widget toggle, or the kill-switch notification's
        // Disconnect after the service had been demoted. So promote
        // unconditionally, then decide what the intent meant.
        //
        // notifications.current() (not the plain builder) is used so promoting
        // never blanks the live speed card that is already on screen.
        startForeground(
            VpnNotifications.NOTIF_ID,
            notifications.current(getString(R.string.state_launching)),
        )

        val action = intent?.action
        if (action == ACTION_DISCONNECT) {
            // STRICT KILL SWITCH (1.2.4): a manual disconnect must not
            // open a leak window. With strict mode on, the first
            // disconnect engages lockdown instead; disconnecting FROM
            // lockdown lifts it. The lockdown branch requires a LIVE
            // session: the error notification keeps its Disconnect action
            // even after a failed connect, and engaging a device-wide
            // blackhole from that dead end would strand the user offline.
            // Never in proxy mode: there is no device tunnel to fail closed,
            // and the blackhole would take the VPN slot from whatever VPN
            // the user runs beside the proxy.
            val last = lastProfile
            when {
                lockdownTunActive -> stopEverything()
                runJob?.isActive == true && last != null && last.strictKillSwitch && !last.proxyMode ->
                    enterLockdown(last)
                else -> stopEverything()
            }
            return START_NOT_STICKY
        }

        // RETRY: the error notification's Retry action. The failed session's
        // profile is still held in lastProfile (a failed connect does not clear
        // it), so reuse it; startTunnel re-reads the Zero Trust secrets itself.
        // When the session is already gone, rebuild from the persisted profile,
        // exactly as a system restart would - never from a default profile.
        // A retry from the kill-switch lockdown lifts it the same way a new
        // connect does (connectAttempt tears the blackhole TUN down first).
        if (action == ACTION_RETRY) {
            val last = lastProfile
            if (last != null) startTunnel(last) else startTunnel(ConnectionProfile(), restored = true)
            return START_STICKY
        }

        // A null intent means the SYSTEM restarted us after the process was
        // killed (START_STICKY). There is no payload then, and decoding null
        // used to yield a DEFAULT profile - so the tunnel silently came back up
        // as AUTO/PRECISE with the kill switch, split tunneling and every other
        // user setting reset. Flag that case so the session is rebuilt from the
        // persisted profile.
        if (intent == null || action == ACTION_CONNECT) {
            val restored = intent == null
            val profile = ProfileCodec.decode(intent?.getStringExtra(EXTRA_PROFILE))
            startTunnel(profile, restored)
            return START_STICKY
        }

        // ACTION HYGIENE: anything else used to fall into the connect branch and
        // bring a tunnel UP with a default profile - a stray or malformed intent
        // could start the VPN with settings the user never chose. An action we do
        // not recognise is a bug on the sender's side; say so and stand down.
        DiagnosticsLog.w(TAG, "Ignoring service intent with unknown action: $action")
        if (runJob?.isActive != true && !lockdownTunActive) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onRevoke() {
        stopEverything()
        super.onRevoke()
    }

    override fun onDestroy() {
        runJob?.cancel()
        cleanupNatives()
        scope.coroutineContext[Job]?.cancel()
        super.onDestroy()
    }

    // ================================================================= connect

    private fun startTunnel(profile: ConnectionProfile, restored: Boolean = false) {
        lastProfile = profile
        // Route line for the busy notification. A restored session may still
        // swap in the persisted chain after hydration; connectFlow updates it.
        notifications.chain = profile.chain
        // 1.2.2 PROTOCOL-SWITCH FIX: this used to bail out silently whenever a
        // previous run coroutine was still winding down ("if active, return"),
        // so a connect tapped right after a disconnect - or right after
        // switching protocol - was simply DROPPED. The user then waited,
        // tapped again, and the app looked like it took forever to start.
        // Now the new session takes ownership: it waits for the old one to
        // finish, tears its natives down, and only then launches the cores.
        val previousRun = runJob
        val previousStop = stopJob
        runJob = scope.launch {
            if (previousRun != null) {
                // Same ordering rule as the disconnect path: cancel, kill the
                // natives (which unblocks the old session immediately), and
                // only then wait for it to finish. Joining first would stall
                // the new connect for as long as the old session's core wait
                // still had to run.
                previousRun.cancel()
                cleanupNatives()
                previousRun.join()
            }
            previousStop?.join()
            try {
                connectFlow(profile, restored)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                AetherController.setState(
                    ConnectionState.Error(e.message ?: getString(R.string.state_error)),
                )
                notifications.update(getString(R.string.state_error))
                cleanupNatives()
            }
        }
    }

    private suspend fun connectFlow(requested: ConnectionProfile, restored: Boolean) {
        DiagnosticsLog.clear()
        // Hydrated AFTER the log is cleared, so its notes survive in the panel.
        val profile = hydrate(requested, restored).also {
            lastProfile = it
            notifications.chain = it.chain
        }
        // STALE-CIRCLES ROOT-CAUSE FIX: the four self-test circles were only
        // reset inside Diagnostics.run(), which starts AFTER the cores have
        // launched AND finished their endpoint scan / bootstrap - so on a
        // reconnect the previous session's green circles sat on screen for the
        // entire scan and appeared to "reset late". Reset them the INSTANT a new
        // connect starts, so the panel always reflects the current attempt.
        Diagnostics.resetChecks()
        EngineMeta.reset()
        ChainRuntime.reset()
        DiagnosticsLog.i(
            TAG,
            "Connect requested - chain=${profile.chain.pathLabel()} " +
                "protocol=${profile.protocol} scan=${profile.scanMode} ip=${profile.ipVersion}",
        )

        // FAIL FAST, WITH A REASON THE USER CAN ACT ON: a build without the
        // Psiphon, Xray or Tor binary is a valid build (they are fetched and
        // compiled by the build scripts, and a fork may not have run them).
        // Saying so here costs milliseconds; discovering it three minutes into
        // a connect attempt costs the user's patience.
        val missing = natives.missingCores(profile.chain)
        if (missing.isNotEmpty()) {
            throw IllegalStateException(
                getString(R.string.err_core_missing, missing.joinToString(", ") { it.label }),
            )
        }

        // SSTP is a packet tunnel with its own session shape - no engine, no
        // SOCKS entry, no forwarder - so it never enters the ladders below.
        if (profile.chain.usesSstp) {
            runSstpSession(profile)
            return
        }

        val resolved: ConnectionProfile = when {
            // No Aether hop means no endpoint scan and nothing for the ladder to
            // vary: Psiphon, Xray and Tor pick their own transports internally.
            !profile.chain.usesAether -> {
                AetherController.setState(ConnectionState.Launching)
                runLadder(
                    ConnectionPlanner.chainOnly(profile),
                    getString(R.string.err_chain_failed),
                    VpnTunables.chainBudgetMs(profile.chain) + VpnTunables.SESSION_SLACK_MS,
                )
            }
            profile.protocol == Protocol.AUTO -> connectSmartAuto(profile)
            else -> {
                // An explicitly chosen protocol keeps that protocol; the
                // engine still selects its own endpoint.
                AetherController.setState(ConnectionState.Launching)
                val plan = ConnectionPlanner.manualProtocol(profile)
                runLadder(
                    plan,
                    getString(R.string.err_protocol_failed),
                    // The first pass keeps its FULL budget (fix/masque-scan);
                    // the anti-DPI pass only gets what is left of the extra.
                    plan.first().timeoutMs + VpnTunables.MANUAL_SESSION_EXTRA_MS +
                        VpnTunables.overlayBudgetMs(profile.chain),
                )
            }
        }

        // Desktop-parity info row (1.2.4): publish what actually won. For a
        // single-core session that is the protocol (Smart Auto resolves AUTO to
        // a concrete one); for a chain the path itself is the useful fact, and
        // the protocol is only one hop of it.
        EngineMeta.setProtocol(
            if (profile.chain == ChainMode.AETHER) resolved.protocol.name
            else profile.chain.pathLabel(),
        )
        if (resolved.manualPeer.isNotBlank()) EngineMeta.setEndpoint(resolved.manualPeer)

        // LIVE SPEED IN THE SHADE: the meter starts BEFORE the Connected
        // transition, so the first notification the user pulls down already
        // carries a reading instead of a bare "Connected".
        notifications.startTrafficMeter()
        AetherController.setState(ConnectionState.Connected(VpnTunables.entryEndpoint))
        notifications.update(getString(R.string.state_connected))
        DiagnosticsLog.i(TAG, "Connect gate passed - tunnel is ready.")
        startHealthCheck(resolved)

        superviseCores(resolved)
    }

    /**
     * Fills in the parts of the profile that cannot travel inside an Intent.
     *
     * - [restored] (system-initiated sticky restart, no payload): the whole
     *   profile is re-read from the DataStore, which is the only place the
     *   user's real settings still exist after a process kill.
     * - Zero Trust secrets are always re-read from the Keystore-sealed
     *   [SecretStore]: [ProfileCodec] deliberately keeps them out of the
     *   Intent, because extras show up in system service dumps.
     * - So is the SSTP password, for the same reason. An empty sealed value
     *   means none was ever saved, and the public VPN Gate default the payload
     *   decoded to stands.
     * - The Xray config never travels in the profile at all: ChainStack reads
     *   it from its own sealed store when the Xray hop starts.
     */
    private suspend fun hydrate(profile: ConnectionProfile, restored: Boolean): ConnectionProfile {
        if (restored) {
            DiagnosticsLog.w(TAG, "Restarted by the system - reconnecting with the saved profile.")
            // ProfileStore already unseals the Zero Trust and SSTP secrets itself.
            val saved = runCatching { ProfileStore(applicationContext).profile.first() }
            (saved.exceptionOrNull() as? CancellationException)?.let { throw it }
            return saved.getOrNull() ?: profile
        }
        var hydrated = profile
        if (profile.teamAuth != TeamAuth.OFF) {
            val secrets = SecretStore(applicationContext)
            hydrated = hydrated.copy(
                accessClientSecret = secrets.read(SecretStore.ACCESS_SECRET),
                accessToken = secrets.read(SecretStore.ACCESS_TOKEN),
            )
        }
        if (profile.chain.usesSstp) {
            val sealed = SecretStore(applicationContext).read(ProfileStore.SSTP_PASSWORD_SECRET)
            if (sealed.isNotEmpty()) {
                hydrated = hydrated.copy(sstpConfig = hydrated.sstpConfig.copy(password = sealed))
            }
        }
        return hydrated
    }

    /**
     * SMART AUTO (root-cause rework of the broken Auto protocol): fingerprint
     * the network's DPI first (see [SmartAuto]), then walk an ordered ladder
     * of concrete strategies - protocol + obfuscation + the IP ranges that
     * actually answered on THIS network - until one passes the connect gate,
     * all inside [StrategyLadder.SESSION_BUDGET_MS]. Returns the strategy that
     * won so the supervisor restarts the engine with the SAME working
     * configuration.
     */
    private suspend fun connectSmartAuto(userProfile: ConnectionProfile): ConnectionProfile {
        AetherController.setState(ConnectionState.Launching)
        notifications.update(getString(R.string.state_analyzing))
        val fingerprint = SmartAuto.fingerprint(this)
        val plan = SmartAuto.buildPlan(userProfile, fingerprint)
        return runLadder(
            plan,
            getString(R.string.err_auto_failed),
            StrategyLadder.SESSION_BUDGET_MS + VpnTunables.overlayBudgetMs(userProfile.chain),
        )
    }

    /**
     * Walks a ladder of strategies until one comes up and passes the connect
     * gate. Each failed rung is torn down before the next is tried.
     *
     * ONE DEADLINE for the whole ladder ([sessionBudgetMs]). Each rung's engine
     * wait is min(its own budget, what is left), the rung as a whole is cut off
     * when it runs past the deadline, and a rung that cannot get
     * [VpnTunables.MIN_RUNG_BUDGET_MS] is not started at all. Without this the
     * worst case was the sum of every rung's budget plus a 90 s self-test each.
     */
    private suspend fun runLadder(
        plan: List<AutoCandidate>,
        failureMessage: String,
        sessionBudgetMs: Long,
    ): ConnectionProfile {
        var lastError: Exception? = null
        val deadline = SystemClock.elapsedRealtime() + sessionBudgetMs
        DiagnosticsLog.i(TAG, "Session budget: ${sessionBudgetMs / 1000}s for ${plan.size} attempt(s).")

        for ((index, candidate) in plan.withIndex()) {
            val remaining = deadline - SystemClock.elapsedRealtime()
            if (remaining < VpnTunables.MIN_RUNG_BUDGET_MS) {
                DiagnosticsLog.w(
                    TAG,
                    "Session budget of ${sessionBudgetMs / 1000}s is spent - " +
                        "skipping the remaining ${plan.size - index} strategy(ies).",
                )
                break
            }
            DiagnosticsLog.i(TAG, "Attempt ${index + 1}/${plan.size} → ${candidate.label}")
            try {
                val engineBudget = minOf(candidate.timeoutMs, remaining)
                val finished = withTimeoutOrNull(remaining) {
                    connectAttempt(candidate.profile, engineBudget, deadline)
                    true
                }
                if (finished == null) {
                    DiagnosticsLog.e(TAG, "${candidate.label} ran past the session budget - stopping it.")
                    throw IllegalStateException(getString(R.string.err_engine_timeout))
                }
                DiagnosticsLog.i(TAG, "Connected using ${candidate.label}")
                return candidate.profile
            } catch (e: CancellationException) {
                throw e
            } catch (e: ChainException) {
                // NOT a rung failure. Every rung of a ladder varies the Aether
                // hop, so retrying one cannot fix "Tor did not bootstrap" or
                // "no Psiphon config" - it would only spend another full Tor
                // bootstrap budget arriving at the same answer.
                cleanupNatives()
                Diagnostics.resetChecks()
                throw IllegalStateException(chainFailureMessage(e.failure), e)
            } catch (e: VpnConsentException) {
                // Not a rung failure either: no other strategy can grant the
                // VPN permission the user just refused (or never saw).
                cleanupNatives()
                Diagnostics.resetChecks()
                throw IllegalStateException(e.message, e)
            } catch (e: Exception) {
                lastError = e
                DiagnosticsLog.w(
                    TAG,
                    "${candidate.label} failed (${e.message}) - moving to the next strategy.",
                )
                cleanupNatives()
                Diagnostics.resetChecks()
            }
        }

        throw IllegalStateException(failureMessage, lastError)
    }

    /** One chain failure, in words the user can do something with. */
    private fun chainFailureMessage(failure: ChainFailure): String = when (failure) {
        ChainFailure.PSIPHON_MISSING -> getString(R.string.err_core_missing, "Psiphon")
        ChainFailure.PSIPHON_CONFIG -> getString(R.string.err_psiphon_config)
        ChainFailure.PSIPHON_TIMEOUT -> getString(R.string.err_psiphon_timeout)
        ChainFailure.TOR_MISSING -> getString(R.string.err_core_missing, "Tor")
        ChainFailure.TOR_TIMEOUT -> getString(R.string.err_tor_timeout)
        ChainFailure.FRONT_BIND -> getString(R.string.err_front_bind)
        ChainFailure.XRAY_MISSING -> getString(R.string.err_core_missing, "Xray")
        ChainFailure.XRAY_CONFIG -> getString(R.string.err_xray_config)
        ChainFailure.XRAY_TIMEOUT -> getString(R.string.err_xray_timeout)
    }

    /**
     * One full connect attempt: launch the cores this chain needs, wait for the
     * chain entry to really carry traffic, bring up TUN/proxy, and gate on the
     * connect gate. Throws on any failure; the caller decides whether to retry
     * differently.
     *
     * [timeoutMs] is the engine's port budget for this rung; [sessionDeadline]
     * (elapsedRealtime) bounds everything after it, the chain included.
     */
    private suspend fun connectAttempt(profile: ConnectionProfile, timeoutMs: Long, sessionDeadline: Long) {
        AetherController.setState(ConnectionState.Launching)
        notifications.update(getString(R.string.state_launching))
        // 1.2.2 PROTOCOL-SWITCH FIX, generalised to the chain: never start a
        // core on top of a dying one. Tear the previous natives down and wait
        // for EVERY port this chain will bind to be released first, otherwise
        // the probes below can "see" an old listener and the whole attempt is
        // verified against a socket that is about to disappear. This is also
        // what lifts a lockdown: the blackhole TUN is torn down here.
        cleanupNatives()
        ChainRuntime.portsFor(profile.chain).forEach { port ->
            val released = PortProbe.awaitClosed(
                VpnTunables.SOCKS_HOST,
                port,
                VpnTunables.PORT_RELEASE_WAIT_MS,
            )
            if (!released) {
                DiagnosticsLog.w(
                    TAG,
                    "Local port $port is still busy after " +
                        "${VpnTunables.PORT_RELEASE_WAIT_MS / 1000}s - starting anyway.",
                )
            }
        }

        if (profile.chain.usesAether) {
            DiagnosticsLog.i(TAG, "Launching engine (libaether.so)…")
            natives.startEngine(profile)

            AetherController.setState(ConnectionState.Connecting)
            notifications.update(getString(R.string.state_connecting))
            // Timeout comes from the caller: the profile's scan-mode budget for a
            // direct connect, or the per-candidate budget in the Smart Auto
            // ladder - both already bounded by the session deadline.
            DiagnosticsLog.i(
                TAG,
                "Waiting for the engine's SOCKS5 on " +
                    "${VpnTunables.SOCKS_HOST}:${VpnTunables.ENGINE_SOCKS_PORT}… " +
                    "(scan=${profile.scanMode}, timeout=${timeoutMs / 1000}s)",
            )
            val opened = PortProbe.awaitOpen(
                VpnTunables.SOCKS_HOST,
                VpnTunables.ENGINE_SOCKS_PORT,
                timeoutMs,
            ) { natives.engineAlive }
            if (!opened) {
                if (!natives.engineAlive) {
                    DiagnosticsLog.e(TAG, "Engine exited before it opened the SOCKS5 port.")
                    throw IllegalStateException(getString(R.string.err_engine_died))
                }
                DiagnosticsLog.e(
                    TAG,
                    "Engine still scanning after ${timeoutMs / 1000}s - SOCKS5 port never opened.",
                )
                throw IllegalStateException(getString(R.string.err_engine_timeout))
            }

            // READINESS, NOT AN OPEN PORT (perf/fast-connect). TUN and hev used
            // to come up the moment the port answered, and the 90 s self-test
            // then waited out whatever the engine still had to do. One real
            // CONNECT through the engine is the actual "ready" signal; a port
            // that never carries one fails THIS rung in seconds instead.
            DiagnosticsLog.i(TAG, "Engine SOCKS5 port is up - checking it carries a real connection…")
            val dataplaneBudget = minOf(
                VpnTunables.ENGINE_DATAPLANE_WAIT_MS,
                (sessionDeadline - SystemClock.elapsedRealtime())
                    .coerceAtLeast(VpnTunables.DATAPLANE_MIN_WAIT_MS),
            )
            val carries = Readiness.awaitDataplane(
                VpnTunables.SOCKS_HOST,
                VpnTunables.ENGINE_SOCKS_PORT,
                dataplaneBudget,
            ) { natives.engineAlive }
            if (!carries) {
                if (!natives.engineAlive) {
                    DiagnosticsLog.e(TAG, "Engine exited before its tunnel carried a connection.")
                    throw IllegalStateException(getString(R.string.err_engine_died))
                }
                DiagnosticsLog.e(
                    TAG,
                    "Engine SOCKS5 is open but no CONNECT got through in " +
                        "${dataplaneBudget / 1000}s - not starting TUN on a dead tunnel.",
                )
                throw IllegalStateException(getString(R.string.err_selftest))
            }
        }

        // The overlay hops, each dialling through the previous one, under the
        // tighter of the session deadline and the chain's own budget. Throws a
        // ChainException naming the core that failed.
        AetherController.setState(ConnectionState.Connecting)
        notifications.update(getString(R.string.state_connecting))
        val chainDeadline = minOf(
            sessionDeadline,
            SystemClock.elapsedRealtime() + VpnTunables.chainBudgetMs(profile.chain),
        )
        val entryPort = natives.startChain(profile, chainDeadline)

        if (profile.proxyMode) {
            // Proxy mode never touches the VPN slot: no TUN, so a VPN the user
            // runs beside the proxy keeps running (see VpnConsent).
            startLocalProxy(profile)
        } else {
            // SECONDARY-VPN FIX: the slot is claimed HERE - the engine has
            // passed its data-plane check and the chain is up - and not at
            // the connect tap, which revoked another VPN minutes before
            // Aether had anything to replace it with.
            val handedOver = claimVpnSlot()
            startFullTunnel(profile, entryPort)
            if (handedOver) awaitChainAfterHandover(profile, entryPort, sessionDeadline)
        }

        // GATING: Connected is reported ONLY after the connect gate passes -
        // port, handshake and a real outbound TCP connection through the entry
        // the user's traffic takes. DNS + HTTP and the exit IP follow in the
        // background (startHealthCheck) instead of holding the button on
        // "Verifying" for up to 90 s.
        AetherController.setState(ConnectionState.Verifying)
        notifications.update(getString(R.string.state_verifying))
        DiagnosticsLog.i(
            TAG,
            if (profile.proxyMode) "Proxy started. Verifying end-to-end connectivity…"
            else "TUN + hev tunnel started. Verifying end-to-end connectivity…",
        )

        if (!selfTest(profile)) {
            DiagnosticsLog.e(TAG, "Connect gate failed - refusing to report Connected.")
            throw IllegalStateException(getString(R.string.err_selftest))
        }
    }

    /**
     * Takes the device's VPN slot NOW, and not one moment earlier.
     *
     * `VpnService.prepare()` is what takes it: with consent already given it
     * silently revokes whichever VPN holds the slot and returns null. That
     * used to happen at the connect tap (MainActivity), so a secondary VPN
     * the user relied on died the instant Connect was pressed. The tap now
     * leaves it alone whenever another VPN is up (see [VpnConsent]) and this
     * runs right before the TUN is established instead - or, on SSTP, right
     * before the dial, because its TCP session could not survive the handover.
     *
     * When consent was never given, the system dialog is requested through
     * [VpnConsent] and shown by the activity; a refusal (or nobody answering
     * within [VPN_CONSENT_WAIT_MS]) ends the session with that reason.
     *
     * Returns true when another VPN was carrying the device until this call,
     * i.e. when connections opened through it have just been cut.
     *
     * @throws VpnConsentException when the permission is missing.
     */
    private suspend fun claimVpnSlot(): Boolean {
        val handover = VpnConsent.anyVpnActive(this)
        val consent = VpnService.prepare(this)
        if (consent != null) {
            DiagnosticsLog.i(TAG, "VPN permission is still needed - asking for it now that the tunnel is ready.")
            val granted = VpnConsent.request(consent, VPN_CONSENT_WAIT_MS)
            if (!granted || VpnService.prepare(this) != null) {
                DiagnosticsLog.e(TAG, "VPN permission was not granted - not taking over the device.")
                throw VpnConsentException(getString(R.string.conn_vpn_denied))
            }
        }
        if (handover) {
            DiagnosticsLog.i(TAG, "Another VPN carried this device until now - Aether takes over from here.")
        }
        return handover
    }

    /**
     * After a handover, wait for the chain entry to carry a real CONNECT again
     * before the connect gate judges it.
     *
     * Whatever the engine (or Psiphon / Xray / Tor) had opened THROUGH the
     * other VPN died with it, and the cores need a moment to re-dial over the
     * device's own network. Never fatal on its own: the gate right after this
     * is still the one that decides.
     */
    private suspend fun awaitChainAfterHandover(
        profile: ConnectionProfile,
        entryPort: Int,
        sessionDeadline: Long,
    ) {
        val budget = minOf(
            VpnTunables.ENGINE_DATAPLANE_WAIT_MS,
            (sessionDeadline - SystemClock.elapsedRealtime())
                .coerceAtLeast(VpnTunables.DATAPLANE_MIN_WAIT_MS),
        )
        DiagnosticsLog.i(TAG, "Checking the chain still carries traffic after the VPN handover…")
        val carries = Readiness.awaitDataplane(VpnTunables.SOCKS_HOST, entryPort, budget) {
            natives.coresAlive(profile)
        }
        if (!carries) {
            DiagnosticsLog.w(
                TAG,
                "No CONNECT through the chain since the handover yet - the connect gate decides.",
            )
        }
    }

    /**
     * Proxy mode: DON'T capture the whole device through a system TUN. Instead
     * expose the chain entry's SOCKS5 + an HTTP proxy so individual apps (or the
     * Wi-Fi proxy setting) can opt in. This is ideal when only one app (e.g.
     * Telegram) needs the tunnel. LAN exposure only happens when the user
     * explicitly turned sharing on.
     */
    private fun startLocalProxy(profile: ConnectionProfile) {
        if (!natives.startLocalProxy(localOnly = !profile.lanShare)) {
            DiagnosticsLog.e(
                TAG,
                "Proxy mode: the fixed local proxy ports could not be opened (see errors above).",
            )
            throw IllegalStateException(getString(R.string.err_proxy_ports))
        }
        // Ports are FIXED (v2rayNG-style standard) - the same values are
        // shown as copyable rows under the Proxy-mode toggle in the UI.
        DiagnosticsLog.i(
            TAG,
            "Proxy mode: system TUN skipped. Local proxy ready - " +
                "SOCKS5 127.0.0.1:${ShareBridge.SOCKS_SHARE_PORT}, HTTP 127.0.0.1:${ShareBridge.HTTP_SHARE_PORT}",
        )
    }

    private fun startFullTunnel(profile: ConnectionProfile, entryPort: Int) {
        natives.establishTun(profile)
        natives.startForwarder(profile, entryPort)
        // LAN sharing: if the user enabled it, expose the tunnel to other
        // devices on the same Wi-Fi/hotspot (HTTP + SOCKS5 bridge).
        if (profile.lanShare) natives.startLanShare()
    }

    /**
     * The port the self-tests run against: the endpoint that actually carries
     * the user's traffic.
     *
     * In proxy mode that is the SHARED SOCKS5 listener - the exact port external
     * apps connect to - so a dead bridge can no longer hide behind a passing
     * chain-entry test. The initial connect got this right while the
     * post-restart check in [superviseCores] did not, which is why the port
     * decision lives in one function that both call.
     */
    private fun selfTestPort(profile: ConnectionProfile): Int =
        if (profile.proxyMode) ShareBridge.socksPort.value ?: VpnTunables.entryPort
        else VpnTunables.entryPort

    /** The connect gate (see [Diagnostics.runGate]) against [selfTestPort]. */
    private suspend fun selfTest(profile: ConnectionProfile): Boolean {
        val port = selfTestPort(profile)
        return try {
            Diagnostics.runGate(port = port)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            false
        }
    }

    /**
     * The DNS + HTTP / exit-IP check, in the BACKGROUND of a live session. It
     * fills in the panel and the IP badge; it never tears the tunnel down - a
     * session that really stops carrying traffic is the watchdog's to judge.
     */
    private fun startHealthCheck(profile: ConnectionProfile) {
        healthJob?.cancel()
        val port = selfTestPort(profile)
        healthJob = scope.launch {
            val healthy = try {
                Diagnostics.runHealthCheck(port = port)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                false
            }
            if (healthy) {
                // Informational only: report where the tunnel actually came out.
                // WARP edges are anycast, so the exit location is decided by the
                // engine's endpoint selection and the operator's routing, not by
                // the app. With a chain, the exit belongs to the LAST hop.
                val exit = AetherController.ipInfo.value?.takeIf { it.viaTunnel }
                if (exit != null) {
                    DiagnosticsLog.i(
                        TAG,
                        "Exit verified through the tunnel: ${exit.ip} (${exit.countryCode ?: "??"})",
                    )
                }
            } else {
                DiagnosticsLog.w(
                    TAG,
                    "Background health check: DNS/HTTP through the tunnel did not answer yet. " +
                        "The tunnel stays up; the watchdog decides whether it is really dead.",
                )
            }
        }
    }

    // ==================================================================== SSTP

    /**
     * An SSTP session, start to finish: dial, build the TUN from the PPP link,
     * pump packets, and keep it up.
     *
     * What does NOT apply, and why it is refused or said rather than ignored:
     *
     *  - Proxy mode needs a SOCKS5 entry to expose, and SSTP has none. Starting
     *    a full-device VPN when the user asked for a per-app proxy would be the
     *    opposite of what they chose, so it is an error with a reason.
     *  - LAN sharing and per-app blocking both ride on the SOCKS forwarder
     *    (ShareBridge / SocksTunBridge). The session runs without them and the
     *    log says so.
     *  - The SOCKS self-test, health check and watchdog probe a local port;
     *    SSTP's own liveness (LCP / SSTP echo, idle timeout in [SstpCore]) is
     *    the signal here instead.
     */
    private suspend fun runSstpSession(profile: ConnectionProfile) {
        val config = profile.sstpConfig
        if (!config.isUsable) throw IllegalStateException(getString(R.string.err_sstp_no_server))
        if (profile.proxyMode) throw IllegalStateException(getString(R.string.err_sstp_proxy_mode))
        if (profile.lanShare) {
            DiagnosticsLog.w(TAG, "LAN sharing relays a SOCKS entry, and SSTP has none - not sharing this session.")
        }
        if (profile.blockedApps.isNotEmpty()) {
            DiagnosticsLog.w(
                TAG,
                "Per-app blocking needs the SOCKS filter bridge, which an SSTP session does not run - " +
                    "${profile.blockedApps.size} blocked app(s) are tunnelled, not blocked.",
            )
        }

        connectSstp(profile)

        EngineMeta.setProtocol(profile.chain.pathLabel())
        EngineMeta.setEndpoint(sstpEndpoint(config))
        notifications.startTrafficMeter()
        AetherController.setState(ConnectionState.Connected(sstpEndpoint(config)))
        notifications.update(getString(R.string.state_connected))
        DiagnosticsLog.i(TAG, "Connect gate passed - SSTP tunnel is ready.")

        superviseSstp(profile)
    }

    /** The first SSTP connect of a session. Throws with a user-facing reason. */
    private suspend fun connectSstp(profile: ConnectionProfile) {
        AetherController.setState(ConnectionState.Launching)
        notifications.update(getString(R.string.state_launching))
        // Same rule as connectAttempt: never start on top of a dying session,
        // and this is also what lifts a kill-switch lockdown.
        cleanupNatives()
        // The VPN slot, right before the dial and not at the tap. Not later
        // either: the SSTP socket has to be protect()ed, which needs the slot,
        // and a TCP session opened through another VPN would die the moment
        // that VPN is revoked. See claimVpnSlot.
        claimVpnSlot()

        AetherController.setState(ConnectionState.Connecting)
        notifications.update(getString(R.string.state_connecting))
        DiagnosticsLog.i(
            TAG,
            "Dialling SSTP ${sstpEndpoint(profile.sstpConfig)} (${profile.sstpConfig.source.name.lowercase()}, " +
                "verify=${profile.sstpConfig.verifyCert})…",
        )
        val info = natives.startSstp(profile, SSTP_CONNECT_TIMEOUT_MS)

        AetherController.setState(ConnectionState.Verifying)
        notifications.update(getString(R.string.state_verifying))
        natives.establishSstpTun(profile, info)
        natives.startSstpBridge()
        // The gate: IPCP finished (startSstp only returns then) and the link is
        // still up now that the TUN exists.
        if (!natives.sstpAlive) throw IllegalStateException(getString(R.string.err_sstp_dropped))
    }

    /**
     * Keeps an SSTP session up. Parks on the core's state rather than polling;
     * when the link drops it is redialled with the same backoff and retry
     * budget as the SOCKS cores, while the current TUN stays up and swallows
     * traffic, so nothing leaks during the gap. Out of retries means the kill
     * switch (when on) or an error.
     */
    private suspend fun superviseSstp(profile: ConnectionProfile) {
        var attempt = 0
        while (currentCoroutineContext().isActive) {
            if (natives.sstpAlive) {
                natives.awaitSstpExit(VpnTunables.WATCHDOG_INTERVAL_MS)
                if (natives.sstpAlive) continue
                DiagnosticsLog.w(
                    TAG,
                    "SSTP link dropped: ${SstpCore.statusMessage.value.ifBlank { "no reason given" }}",
                )
            }

            if (attempt >= maxRetries(profile)) {
                if (profile.killSwitch || profile.strictKillSwitch) {
                    enterLockdown(profile)
                    return
                }
                throw IllegalStateException(getString(R.string.err_sstp_dropped))
            }
            val backoff = VpnTunables.BACKOFF[attempt.coerceAtMost(VpnTunables.BACKOFF.size - 1)]
            attempt++
            AetherController.setState(ConnectionState.Reconnecting(attempt, maxRetries(profile)))
            notifications.update(getString(R.string.state_reconnecting))
            delay(backoff)

            val restarted = runCatching { natives.restartSstp(profile, SSTP_CONNECT_TIMEOUT_MS) }
                .onFailure { error ->
                    if (error is CancellationException) throw error
                    DiagnosticsLog.w(TAG, "SSTP reconnect failed: ${error.message}")
                }
                .isSuccess
            if (restarted && natives.sstpAlive) {
                attempt = 0
                // A new session, so new counters for the meter.
                notifications.startTrafficMeter()
                AetherController.setState(ConnectionState.Connected(sstpEndpoint(profile.sstpConfig)))
                notifications.update(getString(R.string.state_connected))
            }
        }
    }

    private fun sstpEndpoint(config: SstpConfig): String = "${config.hostname.trim()}:${config.port}"

    // =============================================================== supervise

    /** Keeps the session's cores alive; retries with backoff if one dies. */
    private suspend fun superviseCores(profile: ConnectionProfile) {
        var attempt = 0
        watchdog.reset()
        // Tracks THIS coroutine's own cancellation. The old check read the
        // `runJob` field, which a new session overwrites with its own job - so a
        // superseded supervisor could look "still active" and keep restarting
        // cores that belonged to a session nobody was waiting for any more.
        while (currentCoroutineContext().isActive) {
            if (natives.coresAlive(profile)) {
                natives.awaitCoreExit(profile, VpnTunables.WATCHDOG_INTERVAL_MS)
                // STABILITY WATCHDOG (1.2.4, hardened): a core process can stay
                // alive while its session silently dies -- the classic
                // "connected, but after a minute or two no site opens"
                // symptom. Probe end-to-end THROUGH the chain entry and restart
                // only on SUSTAINED failure; see TunnelWatchdog for why the bar
                // is deliberately high.
                if (natives.coresAlive(profile)) {
                    when (watchdog.check()) {
                        TunnelHealth.HEALTHY -> attempt = 0
                        TunnelHealth.DEGRADED -> Unit
                        TunnelHealth.DEAD -> natives.stopCores()
                    }
                }
                continue
            }

            if (attempt >= maxRetries(profile)) {
                // KILL SWITCH (1.2.4): instead of tearing the VPN down and
                // leaking direct, engage the blackhole lockdown. Not in proxy
                // mode: there is no device tunnel to fail closed, and the
                // blackhole would take the VPN slot from whatever VPN the user
                // runs beside the proxy.
                if ((profile.killSwitch || profile.strictKillSwitch) && !profile.proxyMode) {
                    enterLockdown(profile)
                    return
                }
                throw IllegalStateException(getString(R.string.err_engine_died))
            }
            val backoff = VpnTunables.BACKOFF[attempt.coerceAtMost(VpnTunables.BACKOFF.size - 1)]
            attempt++
            AetherController.setState(ConnectionState.Reconnecting(attempt, maxRetries(profile)))
            notifications.update(getString(R.string.state_reconnecting))
            delay(backoff)

            if (!restartCores(profile)) continue

            // Same gate as the initial connect: never claim Connected after
            // a silent core restart until traffic really flows again.
            AetherController.setState(ConnectionState.Verifying)
            notifications.update(getString(R.string.state_verifying))
            if (selfTest(profile)) {
                attempt = 0
                watchdog.reset()
                // The cores were replaced, so the counters the meter polls
                // were rebased: restart it with the new session.
                notifications.startTrafficMeter()
                AetherController.setState(ConnectionState.Connected(VpnTunables.entryEndpoint))
                notifications.update(getString(R.string.state_connected))
                startHealthCheck(profile)
            } else {
                DiagnosticsLog.w(TAG, "Connect gate failed after a core restart - retrying.")
                natives.stopCores()
            }
        }
    }

    /**
     * Restarts every core the chain needs, keeping the TUN and the forwarder up
     * so no leak window opens.
     *
     * The whole chain restarts together even when only one hop died: Psiphon
     * reads its upstream proxy once at startup, Xray its dialer proxy and tor
     * `Socks5Proxy` likewise, so a hop that outlived its own upstream is
     * pointing at a listener that no longer exists. Ports are fixed, so the
     * forwarder finds the new entry exactly where it left the old one.
     */
    private suspend fun restartCores(profile: ConnectionProfile): Boolean {
        natives.stopCores()
        if (profile.chain.usesAether) {
            natives.startEngine(profile)
            val opened = PortProbe.awaitOpen(
                VpnTunables.SOCKS_HOST,
                VpnTunables.ENGINE_SOCKS_PORT,
                profile.connectTimeoutMs(),
            ) { natives.engineAlive }
            if (!opened) return false
            // Same readiness rule as the first connect: an open port is not a
            // tunnel. The chain above it must not start against a dead engine.
            val carries = Readiness.awaitDataplane(
                VpnTunables.SOCKS_HOST,
                VpnTunables.ENGINE_SOCKS_PORT,
                VpnTunables.ENGINE_DATAPLANE_WAIT_MS,
            ) { natives.engineAlive }
            if (!carries) return false
        }
        return runCatching { natives.startChain(profile) }
            .onFailure { error ->
                if (error is CancellationException) throw error
                DiagnosticsLog.w(TAG, "Chain restart failed: ${error.message}")
            }
            .isSuccess
    }

    /** Max automatic core restarts (Smart Reconnect, 1.2.4). */
    private fun maxRetries(profile: ConnectionProfile): Int =
        if (profile.smartReconnect) {
            profile.reconnectRetryLimit.coerceIn(1, VpnTunables.MAX_ENGINE_RESTARTS)
        } else {
            VpnTunables.MAX_ENGINE_RESTARTS
        }

    // ================================================================ teardown

    private fun stopEverything() {
        AetherController.setState(ConnectionState.Disconnecting)
        notifications.update(getString(R.string.state_disconnecting))
        val job = runJob
        runJob = null
        // The session is over: its kill-switch policy must not leak into a
        // later ACTION_DISCONNECT that arrives with nothing running.
        lastProfile = null
        // DISCONNECT MUST BE INSTANT. Order matters:
        //   1. cancel the session coroutine (does not wait for it),
        //   2. kill the natives right away - this is what actually makes the
        //      tunnel stop, and it also unblocks any wait the session
        //      coroutine is parked in,
        //   3. flip the UI to Idle and drop the foreground notification,
        //   4. only THEN join the finished coroutine, off the critical path.
        // The previous order (join -> cleanup) made the button sit on
        // "Disconnecting…" for as long as the supervisor's core wait had
        // left to run - up to a full minute.
        job?.cancel()
        launchTeardown {
            cleanupNatives()
            // STALE-CIRCLES FIX (part 2): clear the finished session's results
            // right at disconnect, so the panel never carries green circles
            // from a dead session into the next connect.
            Diagnostics.resetChecks()
            EngineMeta.reset()
            ChainRuntime.reset()
            AetherController.setState(ConnectionState.Idle)
            // The final Idle transition never goes through notifications.update(),
            // which is what repaints the tile and the widget - so without this
            // they stay on "Disconnecting…" forever.
            notifications.syncTileAndWidget()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            job?.join()
        }
    }

    /**
     * KILL SWITCH lockdown (1.2.4): stop every core and the forwarder but
     * KEEP a blocking full-tunnel TUN up, so every packet is blackholed
     * instead of leaking direct. The service stays foreground; connecting
     * again or disconnecting lifts the lockdown.
     */
    private fun enterLockdown(profile: ConnectionProfile) {
        val job = runJob
        runJob = null
        job?.cancel()
        launchTeardown {
            healthJob?.cancel()
            healthJob = null
            // The speed meter polls hev's and the bridge's counters, so it has
            // to stop BEFORE the natives it reads are torn down.
            notifications.stopTrafficMeter()
            natives.stopForwarding()
            // If the blackhole interface cannot be established (consent
            // revoked, another VPN took over) there is nothing to hold the
            // traffic with - say so instead of pretending to be protected.
            val lockedDown = natives.establishLockdownTun(profile)
            lockdownTunActive = lockedDown
            Diagnostics.resetChecks()
            EngineMeta.reset()
            ChainRuntime.reset()
            if (lockedDown) {
                AetherController.setState(ConnectionState.Error(getString(R.string.state_killswitch)))
                notifications.update(getString(R.string.state_killswitch))
            } else {
                AetherController.setState(
                    ConnectionState.Error(getString(R.string.err_lockdown_failed)),
                )
                notifications.update(getString(R.string.err_lockdown_failed))
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
            job?.join()
        }
    }

    /**
     * Runs a teardown on the IO dispatcher, AFTER any teardown that is still
     * finishing.
     *
     * Chaining matters: [stopJob] used to be overwritten outright, so a second
     * disconnect (or a disconnect immediately followed by a lockdown) dropped
     * the reference to the teardown still in flight, and the next connect only
     * waited for the last one - which could easily finish first.
     */
    private fun launchTeardown(block: suspend () -> Unit) {
        val previous = stopJob
        stopJob = scope.launch(Dispatchers.IO) {
            previous?.join()
            block()
        }
    }

    /** Stops every native piece of the session, including the TUN. */
    private fun cleanupNatives() {
        // The background health check probes the natives below.
        healthJob?.cancel()
        healthJob = null
        // Meter first: it polls counters that belong to the natives below.
        notifications.stopTrafficMeter()
        natives.teardown()
        lockdownTunActive = false
    }

    companion object {
        const val ACTION_CONNECT = "studio.cluvex.aether.CONNECT"
        const val ACTION_DISCONNECT = "studio.cluvex.aether.DISCONNECT"

        /** The error notification's Retry action. See onStartCommand. */
        const val ACTION_RETRY = "studio.cluvex.aether.RETRY"
        const val EXTRA_PROFILE = "profile"

        /**
         * One SSTP dial, end to end: TCP (10 s) + TLS (15 s) + the SSTP call
         * (15 s) + LCP / sign-in / IPCP (45 s), which are SstpCore's own
         * bounds, plus slack. A VPN Gate relay that needs longer than this is
         * not one worth waiting on.
         */
        private const val SSTP_CONNECT_TIMEOUT_MS = 95_000L

        /**
         * How long a session waits for the user to answer a VPN consent dialog
         * it asked for (see [claimVpnSlot]). Long enough to read it; bounded so
         * a dialog nobody can see (the activity is not on screen) does not
         * hold the session forever.
         */
        private const val VPN_CONSENT_WAIT_MS = 120_000L

        private const val TAG = "vpn"
    }
}

/**
 * The VPN permission is missing and was not granted when asked. Not a rung
 * failure: no other strategy of the ladder can fix it (see runLadder).
 */
private class VpnConsentException(message: String) : Exception(message)
