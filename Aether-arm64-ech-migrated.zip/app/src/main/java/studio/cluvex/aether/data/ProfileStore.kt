package studio.cluvex.aether.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.map
import studio.cluvex.aether.core.BridgePlan
import studio.cluvex.aether.model.BridgeTransport
import studio.cluvex.aether.model.ChainMode
import studio.cluvex.aether.model.ConnectionProfile
import studio.cluvex.aether.model.CoreLogLevel
import studio.cluvex.aether.model.EndpointMode
import studio.cluvex.aether.model.IpVersion
import studio.cluvex.aether.model.Noize
import studio.cluvex.aether.model.Protocol
import studio.cluvex.aether.model.PsiphonProtocol
import studio.cluvex.aether.model.ScanMode
import studio.cluvex.aether.model.SmartDnsProtocol
import studio.cluvex.aether.model.SplitMode
import studio.cluvex.aether.model.SpoofMode
import studio.cluvex.aether.model.SstpConfig
import studio.cluvex.aether.model.SstpSource
import studio.cluvex.aether.model.TeamAuth
import studio.cluvex.aether.model.TorBridgeMode

private val Context.dataStore by preferencesDataStore(name = "aether_profile")

/** Persists the last-used [ConnectionProfile] with Jetpack DataStore. */
class ProfileStore(private val context: Context) {
    private object Keys {
        val protocol = stringPreferencesKey("protocol")
        val scan = stringPreferencesKey("scan")
        val ip = stringPreferencesKey("ip")
        val quick = booleanPreferencesKey("quick")
        val h2 = booleanPreferencesKey("h2")
        val share = booleanPreferencesKey("share")
        // Added in 1.2.0
        val noize = stringPreferencesKey("noize")
        /**
         * True once this profile has been written by a build whose engine
         * honours an explicit OFF. See the obfuscation migration in [profile]:
         * without it, an OFF stored by an older build cannot be told apart
         * from a deliberate "run without obfuscation".
         */
        val noizeChosen = booleanPreferencesKey("noizeChosen")
        val endpoint = stringPreferencesKey("endpoint")
        val peer = stringPreferencesKey("peer")
        val range = stringPreferencesKey("range")
        val keepalive = intPreferencesKey("keepalive")
        val fragment = booleanPreferencesKey("fragment")
        val ech = booleanPreferencesKey("ech")
        val mtu = intPreferencesKey("mtu")
        val proxy = booleanPreferencesKey("proxy")
        val split = stringPreferencesKey("split")
        val splitApps = stringPreferencesKey("splitApps")
        // Added in 1.2.3 (engine v1.5.0)
        val dns = stringPreferencesKey("dns")
        val team = stringPreferencesKey("team")
        val teamAuth = stringPreferencesKey("teamAuth")
        val accessId = stringPreferencesKey("accessId")
        val accessEmail = stringPreferencesKey("accessEmail")
        val gateway = booleanPreferencesKey("gateway")
        val routeBlock = stringPreferencesKey("routeBlock")
        val routeDirect = stringPreferencesKey("routeDirect")
        // Added in 1.2.4 (feature parity)
        val killSwitch = booleanPreferencesKey("killSwitch")
        val strictKillSwitch = booleanPreferencesKey("strictKillSwitch")
        val ipv6Leak = booleanPreferencesKey("ipv6Leak")
        val smartReconnect = booleanPreferencesKey("smartReconnect")
        val reconnectRetryLimit = intPreferencesKey("reconnectRetryLimit")
        val fragmentSize = stringPreferencesKey("fragmentSize")
        val fragmentDelay = stringPreferencesKey("fragmentDelay")
        val noDataCheck = booleanPreferencesKey("noDataCheck")
        val tlsGroups = stringPreferencesKey("tlsGroups")
        val validateSecs = intPreferencesKey("validateSecs")
        val reconnectSecs = intPreferencesKey("reconnectSecs")
        val noProfileRetry = booleanPreferencesKey("noProfileRetry")
        val coreLogLevel = stringPreferencesKey("coreLogLevel")
        val blockedApps = stringPreferencesKey("blockedApps")
        // Added in 1.5.0 (chained cores: Psiphon / Tor)
        val chain = stringPreferencesKey("chain")
        val psiphonRegion = stringPreferencesKey("psiphonRegion")
        val psiphonConfig = stringPreferencesKey("psiphonConfig")
        val torExitCountry = stringPreferencesKey("torExitCountry")
        val torStrictNodes = booleanPreferencesKey("torStrictNodes")
        // Added in 1.4.7 (Tor bridges)
        val torBridgeMode = stringPreferencesKey("torBridgeMode")
        val torBridgeTransport = stringPreferencesKey("torBridgeTransport")
        /**
         * True once this profile has been written by a build that could have
         * stored something other than OFF. Exactly the [noizeChosen] problem:
         * every profile 1.4.7 ever saved carries `torBridgeMode=OFF`, because
         * OFF was the default and `save` always writes the key - so without
         * this marker "bridges are off" and "this profile predates bridges
         * being on by default" are the same three letters on disk.
         */
        val torBridgeChosen = booleanPreferencesKey("torBridgeChosen")
        /**
         * Newline separated, exactly as tor will receive them. A preferences
         * file has no line framing of its own, so unlike the Intent payload
         * (see ProfileCodec) nothing has to be folded here.
         */
        val torBridgeLines = stringPreferencesKey("torBridgeLines")
        // Added in 2.0.0 (engine v2.0.0)
        val mimOuter = stringPreferencesKey("mimOuter")
        val mimInner = stringPreferencesKey("mimInner")
        /**
         * The QUIC v2 opener, which is ON in the engine. Read with the
         * profile's own default rather than `false`, so a profile saved before
         * this key existed is not read as "the user switched it off".
         */
        val quicV2 = booleanPreferencesKey("quicV2")
        val socketMark = stringPreferencesKey("socketMark")
        val maxClients = intPreferencesKey("maxClients")
        val halfCloseSecs = intPreferencesKey("halfCloseSecs")
        val tcpKeepaliveSecs = intPreferencesKey("tcpKeepaliveSecs")
        val tcpConnectSecs = intPreferencesKey("tcpConnectSecs")
        // Psiphon CDN fronting. Same key names as ProfileCodec.
        val psiphonProtocol = stringPreferencesKey("psiphonProtocol")
        val psiphonCdnIps = stringPreferencesKey("psiphonCdnIps")
        val psiphonCdnSni = stringPreferencesKey("psiphonCdnSni")
        // Added in 2.2.0 (MASQUE spoofing). Both keys read with the profile's
        // own defaults, so a profile saved before they existed means OFF/blank
        // exactly as a fresh one does.
        val spoofMode = stringPreferencesKey("spoofMode")
        val spoofSni = stringPreferencesKey("spoofSni")
        // Smart DNS. Same key names as ProfileCodec; all of them read with the
        // profile's own defaults, so an older profile means "off, plain DNS".
        val smartDns = booleanPreferencesKey("smartDns")
        val smartDnsProtocol = stringPreferencesKey("smartDnsProtocol")
        val smartDnsServers = stringPreferencesKey("smartDnsServers")
        // SSTP. Same key names as ProfileCodec; the password is NOT here (see
        // [SSTP_PASSWORD_SECRET]). [sstpHost] doubles as "this profile has
        // saved SSTP settings": before it exists the password is the public
        // VPN Gate default, after it the sealed value is taken as is.
        val sstpHost = stringPreferencesKey("sstpHost")
        val sstpPort = intPreferencesKey("sstpPort")
        val sstpUser = stringPreferencesKey("sstpUser")
        val sstpVerify = booleanPreferencesKey("sstpVerify")
        val sstpSni = stringPreferencesKey("sstpSni")
        val sstpMru = intPreferencesKey("sstpMru")
        val sstpMtu = intPreferencesKey("sstpMtu")
        val sstpSource = stringPreferencesKey("sstpSource")
        val sstpCountry = stringPreferencesKey("sstpCountry")
        val sstpCountryName = stringPreferencesKey("sstpCountryName")

        // ---- RETIRED keys: read once for migration, removed on save ----

        /**
         * The MASQUE-in-MASQUE switch from before it became [Protocol.MIM].
         * Read by [profile] so MASQUE + mim=true migrates to MIM.
         */
        val legacyMim = booleanPreferencesKey("mim")

        /**
         * The engine's own tor (v2.0.0). The app runs one Tor - TorCore, via
         * the chain modes - so these are never read, only deleted, so that a
         * stale placement cannot sit in a backup or a bug report looking live.
         */
        val retiredEngineTor = listOf(
            stringPreferencesKey("engineTor"),
            stringPreferencesKey("engineTorBridges"),
            stringPreferencesKey("engineTorBridgeLines"),
            stringPreferencesKey("engineTorCountry"),
        )
        val retiredEngineTorBind = intPreferencesKey("engineTorBind")

        /**
         * Smart DNS's manual direct switch and proxy list. The direct path is
         * chosen automatically now and the proxy ranges are detected per
         * session, so these are never read, only deleted.
         */
        val retiredSmartDnsDirect = booleanPreferencesKey("smartDnsDirect")
        val retiredSmartDnsProxies = stringPreferencesKey("smartDnsProxies")
    }

    /**
     * Zero Trust secrets (service-token secret + enrolment JWT) are NOT kept in
     * the DataStore preferences file. That file is plain protobuf inside the app
     * sandbox, so a device backup or an adb dump on a rooted phone would expose
     * a long-lived organization credential. They live in [SecretStore] instead,
     * sealed with a hardware-backed AES-GCM key from the Android Keystore. The
     * SSTP password ([SSTP_PASSWORD_SECRET]) is sealed there too: for a private
     * SSTP server it is a real account password.
     *
     * The Psiphon client config deliberately stays HERE: it is a public,
     * network-issued client identity (propagation channel + sponsor + server
     * list URLs), not a user credential, and every Psiphon client ships one.
     *
     * Bridge lines stay here too, and that is a deliberate call rather than an
     * oversight: a bridge address is not a credential (it authenticates nobody
     * and is shared by everyone using that bridge), and the alternative -
     * sealing them - would make them unreadable to a user trying to copy their
     * working bridges to another device, which is a thing people on filtered
     * networks actually do. What they ARE is sensitive in a different sense: a
     * personal bridge in a screenshot is a bridge that can be reported. The UI
     * says so where it matters.
     */
    private val secrets = SecretStore(context)

    val profile: Flow<ConnectionProfile> = context.dataStore.data
        // Persist the ECH default for upgraded installs too. Reading `false`
        // as `true` fixes the active profile in memory, but without this write
        // the old value remains on disk until some unrelated setting changes.
        // DataStore emits once more after this edit, then the guard is stable.
        .onEach { prefs ->
            if (prefs[Keys.ech] != true) {
                context.dataStore.edit { it[Keys.ech] = true }
            }
        }
        .map { prefs ->
        val d = ConnectionProfile()
        // MIGRATION (obfuscation): an OFF stored by an older build is NOT a
        // choice to run bare. Back then OFF meant "emit no --noize", and the
        // engine then applied its own defaults (firewall for MASQUE, balanced
        // for WireGuard) - so that profile has always connected WITH
        // obfuscation. Now that the engine honours OFF verbatim, reading such a
        // value literally would silently strip the junk packets a filtered
        // network needs, and a MASQUE scan on it simply finds nothing.
        //
        // So a stored OFF is read as the default until this profile is written
        // by a build that honours OFF ([Keys.noizeChosen], set by [save]).
        // After that, OFF is respected exactly as chosen.
        val storedNoize = prefs[Keys.noize]?.let { runCatching { Noize.valueOf(it) }.getOrNull() }
        val noizeChosen = prefs[Keys.noizeChosen] ?: false
        val noize = when {
            storedNoize == null -> d.noize
            storedNoize == Noize.OFF && !noizeChosen -> d.noize
            else -> storedNoize
        }

        // MIGRATION (bridges), same shape and same reason. Bridges are now on by
        // default (see ConnectionProfile.torBridgeMode), and every profile 1.4.7
        // saved says OFF because that was the only default there was. Reading
        // those literally would keep the feature switched off for exactly the
        // users who already went looking for a Tor chain mode.
        val storedBridgeMode = TorBridgeMode.fromStored(prefs[Keys.torBridgeMode])
        val bridgeChosen = prefs[Keys.torBridgeChosen] ?: false
        val bridgeMode = when {
            storedBridgeMode == null -> d.torBridgeMode
            storedBridgeMode == TorBridgeMode.OFF && !bridgeChosen -> d.torBridgeMode
            else -> storedBridgeMode
        }
        val storedTransport = BridgeTransport.fromStored(prefs[Keys.torBridgeTransport])
            ?: d.torBridgeTransport
        val storedBridgeLines = prefs[Keys.torBridgeLines]

        // ECH migration: legacy false is intentionally ignored in this build.
        // The onEach above also rewrites the stored value, so this is a real
        // migration rather than only an in-memory override.
        val ech = true

        // SEEDING, exactly once. A default of "built-in bridges" with an empty
        // list is a page that says bridges are on and shows nothing selected, so
        // the bundled catalogue is copied in - the same lines the user would have
        // got by tapping "use all", chosen by the same ladder the session uses.
        //
        // The condition is the key being ABSENT, not blank: [save] always writes
        // it, so a user who cleared their list has an empty string on disk and
        // stays cleared. It is therefore read at most once per install, which is
        // also what keeps an asset read out of every recomposition.
        val seeded = if (storedBridgeLines == null && bridgeMode == TorBridgeMode.BUILTIN) {
            runCatching { BridgePlan.initialSelection(context, storedTransport) }.getOrNull()
        } else {
            null
        }

        // MIGRATION (MASQUE-in-MASQUE): it used to be a switch beside the
        // protocol and is a protocol now. MASQUE + mim=true is read as MIM.
        val storedProtocol = prefs[Keys.protocol]
            ?.let { runCatching { Protocol.valueOf(it) }.getOrNull() } ?: Protocol.AUTO

        // SSTP. Before this profile ever saved SSTP settings the password is
        // the public VPN Gate default; after that, whatever is sealed - an
        // empty field the user cleared stays empty instead of springing back.
        val ds = d.sstpConfig
        val sstp = SstpConfig(
            hostname = prefs[Keys.sstpHost] ?: ds.hostname,
            port = prefs[Keys.sstpPort]?.takeIf { it in 1..65535 } ?: ds.port,
            username = prefs[Keys.sstpUser] ?: ds.username,
            password = if (prefs[Keys.sstpHost] == null) ds.password else secrets.read(SSTP_PASSWORD_SECRET),
            verifyCert = prefs[Keys.sstpVerify] ?: ds.verifyCert,
            customSni = prefs[Keys.sstpSni] ?: ds.customSni,
            mru = prefs[Keys.sstpMru] ?: ds.mru,
            mtu = prefs[Keys.sstpMtu] ?: ds.mtu,
            source = prefs[Keys.sstpSource]
                ?.let { runCatching { SstpSource.valueOf(it) }.getOrNull() } ?: ds.source,
            countryCode = prefs[Keys.sstpCountry] ?: ds.countryCode,
            countryName = prefs[Keys.sstpCountryName] ?: ds.countryName,
        )

        ConnectionProfile(
            protocol = Protocol.migrateLegacyMim(storedProtocol, prefs[Keys.legacyMim]),
            // Not valueOf(): the five-mode set was retired in 1.4.6 and this
            // file still holds whatever the user picked before, so the stored
            // name is MIGRATED rather than dropped on the floor.
            scanMode = ScanMode.fromStored(prefs[Keys.scan]) ?: d.scanMode,
            ipVersion = prefs[Keys.ip]
                ?.let { runCatching { IpVersion.valueOf(it) }.getOrNull() } ?: IpVersion.V4,
            quickReconnect = prefs[Keys.quick] ?: true,
            masqueHttp2 = prefs[Keys.h2] ?: false,
            lanShare = prefs[Keys.share] ?: false,
            noize = noize,
            endpointMode = prefs[Keys.endpoint]
                ?.let { runCatching { EndpointMode.valueOf(it) }.getOrNull() } ?: EndpointMode.AUTO,
            manualPeer = prefs[Keys.peer] ?: "",
            manualRange = prefs[Keys.range] ?: "",
            keepalive = prefs[Keys.keepalive] ?: 0,
            fragment = prefs[Keys.fragment] ?: false,
            ech = ech,
            mtu = prefs[Keys.mtu] ?: d.mtu,
            proxyMode = prefs[Keys.proxy] ?: false,
            splitMode = prefs[Keys.split]
                ?.let { runCatching { SplitMode.valueOf(it) }.getOrNull() } ?: SplitMode.OFF,
            splitApps = prefs[Keys.splitApps]
                ?.split(",")?.map { it.trim() }?.filter { it.isNotEmpty() } ?: emptyList(),
            dnsServers = prefs[Keys.dns] ?: "",
            team = prefs[Keys.team] ?: "",
            teamAuth = prefs[Keys.teamAuth]
                ?.let { runCatching { TeamAuth.valueOf(it) }.getOrNull() } ?: TeamAuth.OFF,
            accessClientId = prefs[Keys.accessId] ?: "",
            accessClientSecret = secrets.read(SecretStore.ACCESS_SECRET),
            accessEmail = prefs[Keys.accessEmail] ?: "",
            accessToken = secrets.read(SecretStore.ACCESS_TOKEN),
            gateway = prefs[Keys.gateway] ?: false,
            routeBlock = prefs[Keys.routeBlock] ?: "",
            routeDirect = prefs[Keys.routeDirect] ?: "",
            killSwitch = prefs[Keys.killSwitch] ?: false,
            strictKillSwitch = prefs[Keys.strictKillSwitch] ?: false,
            ipv6LeakProtection = prefs[Keys.ipv6Leak] ?: true,
            smartReconnect = prefs[Keys.smartReconnect] ?: true,
            reconnectRetryLimit = prefs[Keys.reconnectRetryLimit] ?: 5,
            fragmentSize = prefs[Keys.fragmentSize] ?: "",
            fragmentDelay = prefs[Keys.fragmentDelay] ?: "",
            noDataCheck = prefs[Keys.noDataCheck] ?: false,
            tlsGroups = prefs[Keys.tlsGroups] ?: "",
            validateSecs = prefs[Keys.validateSecs] ?: 0,
            reconnectSecs = prefs[Keys.reconnectSecs] ?: 0,
            noProfileRetry = prefs[Keys.noProfileRetry] ?: false,
            coreLogLevel = prefs[Keys.coreLogLevel]
                ?.let { runCatching { CoreLogLevel.valueOf(it) }.getOrNull() } ?: CoreLogLevel.WARN,
            blockedApps = prefs[Keys.blockedApps]
                ?.split(",")?.map { it.trim() }?.filter { it.isNotEmpty() } ?: emptyList(),
            chain = ChainMode.fromStored(prefs[Keys.chain]) ?: d.chain,
            psiphonRegion = prefs[Keys.psiphonRegion] ?: "",
            psiphonConfig = prefs[Keys.psiphonConfig] ?: "",
            torExitCountry = prefs[Keys.torExitCountry] ?: "",
            torStrictNodes = prefs[Keys.torStrictNodes] ?: false,
            // Not valueOf(): both enums accept the aliases a hand-written or
            // imported config can carry ("manual", "meek-azure", ...), and a
            // value neither understands keeps the default instead of throwing
            // the whole profile away. The three values below are resolved above,
            // because the bridge default is a migration and not a plain read.
            torBridgeMode = bridgeMode,
            torBridgeTransport = seeded?.first ?: storedTransport,
            torBridgeLines = seeded?.second ?: storedBridgeLines ?: "",
            // ---- engine v2.0.0 ----
            mimOuterPeer = prefs[Keys.mimOuter] ?: "",
            mimInnerPeer = prefs[Keys.mimInner] ?: "",
            quicV2Opener = prefs[Keys.quicV2] ?: d.quicV2Opener,
            socketMark = prefs[Keys.socketMark] ?: "",
            maxClients = prefs[Keys.maxClients] ?: 0,
            halfCloseSecs = prefs[Keys.halfCloseSecs] ?: 0,
            tcpKeepaliveSecs = prefs[Keys.tcpKeepaliveSecs] ?: 0,
            tcpConnectSecs = prefs[Keys.tcpConnectSecs] ?: 0,
            // ---- Psiphon CDN fronting ----
            psiphonProtocol = PsiphonProtocol.fromStored(prefs[Keys.psiphonProtocol]) ?: d.psiphonProtocol,
            psiphonCdnEdgeIps = prefs[Keys.psiphonCdnIps] ?: "",
            psiphonCdnSni = prefs[Keys.psiphonCdnSni] ?: "",
            // ---- MASQUE spoofing (2.2.0). Not valueOf(): fromStored also
            // understands the reference repo's option names ("wrong_seq" and
            // friends), and anything unrecognised keeps the OFF default
            // instead of throwing the whole profile away.
            spoofMode = SpoofMode.fromStored(prefs[Keys.spoofMode]) ?: d.spoofMode,
            spoofSni = prefs[Keys.spoofSni] ?: "",
            // ---- Smart DNS ----
            smartDns = prefs[Keys.smartDns] ?: d.smartDns,
            smartDnsProtocol = SmartDnsProtocol.fromStored(prefs[Keys.smartDnsProtocol])
                ?: d.smartDnsProtocol,
            smartDnsServers = prefs[Keys.smartDnsServers] ?: d.smartDnsServers,
            // ---- SSTP ----
            sstpConfig = sstp,
        )
    }

    suspend fun save(profile: ConnectionProfile) {
        context.dataStore.edit { prefs ->
            prefs[Keys.protocol] = profile.protocol.name
            prefs[Keys.scan] = profile.scanMode.name
            prefs[Keys.ip] = profile.ipVersion.name
            prefs[Keys.quick] = profile.quickReconnect
            prefs[Keys.h2] = profile.masqueHttp2
            prefs[Keys.share] = profile.lanShare
            prefs[Keys.noize] = profile.noize.name
            // From here on this profile's obfuscation value is taken literally,
            // OFF included: it was written by a build that honours it.
            prefs[Keys.noizeChosen] = true
            prefs[Keys.endpoint] = profile.endpointMode.name
            prefs[Keys.peer] = profile.manualPeer
            prefs[Keys.range] = profile.manualRange
            prefs[Keys.keepalive] = profile.keepalive
            prefs[Keys.fragment] = profile.fragment
            prefs[Keys.ech] = true
            prefs[Keys.mtu] = profile.mtu
            prefs[Keys.proxy] = profile.proxyMode
            prefs[Keys.split] = profile.splitMode.name
            prefs[Keys.splitApps] = profile.splitApps.joinToString(",")
            prefs[Keys.dns] = profile.dnsServers
            prefs[Keys.team] = profile.team
            prefs[Keys.teamAuth] = profile.teamAuth.name
            prefs[Keys.accessId] = profile.accessClientId
            prefs[Keys.accessEmail] = profile.accessEmail
            prefs[Keys.gateway] = profile.gateway
            prefs[Keys.routeBlock] = profile.routeBlock
            prefs[Keys.routeDirect] = profile.routeDirect
            prefs[Keys.killSwitch] = profile.killSwitch
            prefs[Keys.strictKillSwitch] = profile.strictKillSwitch
            prefs[Keys.ipv6Leak] = profile.ipv6LeakProtection
            prefs[Keys.smartReconnect] = profile.smartReconnect
            prefs[Keys.reconnectRetryLimit] = profile.reconnectRetryLimit
            prefs[Keys.fragmentSize] = profile.fragmentSize
            prefs[Keys.fragmentDelay] = profile.fragmentDelay
            prefs[Keys.noDataCheck] = profile.noDataCheck
            prefs[Keys.tlsGroups] = profile.tlsGroups
            prefs[Keys.validateSecs] = profile.validateSecs
            prefs[Keys.reconnectSecs] = profile.reconnectSecs
            prefs[Keys.noProfileRetry] = profile.noProfileRetry
            prefs[Keys.coreLogLevel] = profile.coreLogLevel.name
            prefs[Keys.blockedApps] = profile.blockedApps.joinToString(",")
            prefs[Keys.chain] = profile.chain.name
            prefs[Keys.psiphonRegion] = profile.psiphonRegion
            prefs[Keys.psiphonConfig] = profile.psiphonConfig
            prefs[Keys.torExitCountry] = profile.torExitCountry
            prefs[Keys.torStrictNodes] = profile.torStrictNodes
            prefs[Keys.torBridgeMode] = profile.torBridgeMode.name
            // Same contract as noizeChosen: from here on OFF means the user
            // chose OFF, and the migration above leaves this profile alone.
            prefs[Keys.torBridgeChosen] = true
            prefs[Keys.torBridgeTransport] = profile.torBridgeTransport.name
            prefs[Keys.torBridgeLines] = profile.torBridgeLines
            // ---- engine v2.0.0 ----
            prefs[Keys.mimOuter] = profile.mimOuterPeer
            prefs[Keys.mimInner] = profile.mimInnerPeer
            prefs[Keys.quicV2] = profile.quicV2Opener
            prefs[Keys.socketMark] = profile.socketMark
            prefs[Keys.maxClients] = profile.maxClients
            prefs[Keys.halfCloseSecs] = profile.halfCloseSecs
            prefs[Keys.tcpKeepaliveSecs] = profile.tcpKeepaliveSecs
            prefs[Keys.tcpConnectSecs] = profile.tcpConnectSecs
            // ---- Psiphon CDN fronting ----
            prefs[Keys.psiphonProtocol] = profile.psiphonProtocol.name
            prefs[Keys.psiphonCdnIps] = profile.psiphonCdnEdgeIps
            prefs[Keys.psiphonCdnSni] = profile.psiphonCdnSni
            // ---- MASQUE spoofing (2.2.0). Stored verbatim, even on a
            // transport where it cannot take effect: the user set it, and
            // effectiveSpoofMode decides what is EMITTED per connect.
            prefs[Keys.spoofMode] = profile.spoofMode.name
            prefs[Keys.spoofSni] = profile.spoofSni
            // ---- Smart DNS. Stored verbatim on every chain, like spoofing:
            // usesSmartDns decides per connect whether it applies.
            prefs[Keys.smartDns] = profile.smartDns
            prefs[Keys.smartDnsProtocol] = profile.smartDnsProtocol.name
            prefs[Keys.smartDnsServers] = profile.smartDnsServers
            // ---- SSTP. Stored on every chain, so switching away from SSTP
            // and back keeps the relay. The password is sealed below.
            val sstp = profile.sstpConfig
            prefs[Keys.sstpHost] = sstp.hostname
            prefs[Keys.sstpPort] = sstp.port
            prefs[Keys.sstpUser] = sstp.username
            prefs[Keys.sstpVerify] = sstp.verifyCert
            prefs[Keys.sstpSni] = sstp.customSni
            prefs[Keys.sstpMru] = sstp.mru
            prefs[Keys.sstpMtu] = sstp.mtu
            prefs[Keys.sstpSource] = sstp.source.name
            prefs[Keys.sstpCountry] = sstp.countryCode
            prefs[Keys.sstpCountryName] = sstp.countryName
            // Retired keys. The protocol written above already carries the
            // MIM choice, so the old switch has nothing left to say, the
            // engine-Tor keys describe a Tor this app no longer runs, and
            // Smart DNS picks its path and proxies by itself now.
            prefs.remove(Keys.legacyMim)
            Keys.retiredEngineTor.forEach { prefs.remove(it) }
            prefs.remove(Keys.retiredEngineTorBind)
            prefs.remove(Keys.retiredSmartDnsDirect)
            prefs.remove(Keys.retiredSmartDnsProxies)
        }
        // Secrets go to the Keystore-sealed store, never to the prefs file.
        // Writing a blank value clears the entry, so "Reset settings" (which
        // saves a default profile) wipes them through this same path.
        secrets.write(SecretStore.ACCESS_SECRET, profile.accessClientSecret)
        secrets.write(SecretStore.ACCESS_TOKEN, profile.accessToken)
        secrets.write(SSTP_PASSWORD_SECRET, profile.sstpConfig.password)
    }

    companion object {
        /**
         * The [SecretStore] entry holding [SstpConfig.password]. Read by the
         * VpnService's `hydrate`, because the Intent payload never carries it.
         */
        const val SSTP_PASSWORD_SECRET = "sstp_password"
    }
}
