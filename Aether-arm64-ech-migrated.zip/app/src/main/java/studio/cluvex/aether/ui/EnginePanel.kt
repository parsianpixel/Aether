package studio.cluvex.aether.ui

import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import studio.cluvex.aether.R
import studio.cluvex.aether.model.ConnectionProfile
import studio.cluvex.aether.ui.components.AppPickerDialog
import studio.cluvex.aether.ui.components.Hint
import studio.cluvex.aether.ui.engine.*

private enum class AppPicker { SPLIT, BLOCKED }

/**
 * Renders ONE engine category, because each of them is now its own
 * destination.
 *
 * Smart DNS is not here any more: it lives on the connection tab
 * (SmartDnsHome.kt), next to the other choices people make between attempts.
 */
@Composable
internal fun EngineDestination(
    page: SettingsPage,
    profile: ConnectionProfile,
    onProfileChange: (ConnectionProfile) -> Unit,
    enabled: Boolean,
    modifier: Modifier = Modifier,
) {
    var picker by rememberSaveable { mutableStateOf<AppPicker?>(null) }
    val latest by rememberUpdatedState(profile)
    val latestEnabled by rememberUpdatedState(enabled)
    val focus = LocalFocusManager.current
    val edit: ProfileEdit = remember(onProfileChange) {
        { change -> if (latestEnabled) onProfileChange(latest.change()) }
    }
    // The RESULT of a network fetch the user asked for (Tor bridges from moat
    // or the built-in list). Not refused mid-session: fetching while connected
    // is exactly when bridges.torproject.org is reachable, and the lines only
    // take effect on the next connect. Everything the user picks or types
    // still goes through [edit] and stays locked.
    val fetchEdit: ProfileEdit = remember(onProfileChange) {
        { change -> onProfileChange(latest.change()) }
    }
    LaunchedEffect(enabled) {
        if (!enabled) {
            picker = null
            focus.clearFocus(force = true)
        }
    }
    Column(modifier.fillMaxWidth()) {
        when (page) {
            SettingsPage.CONNECTION -> ConnectionSection(
                protocol = profile.protocol, scanMode = profile.scanMode,
                endpointMode = profile.endpointMode, manualPeer = profile.manualPeer,
                manualRange = profile.manualRange, ipVersion = profile.ipVersion,
                mimOuterPeer = profile.mimOuterPeer, mimInnerPeer = profile.mimInnerPeer,
                masqueHttp2 = profile.masqueHttp2,
                enabled = enabled, edit = edit,
            )
            SettingsPage.CHAIN -> {
                ChainSection(
                    chain = profile.chain, psiphonRegion = profile.psiphonRegion,
                    psiphonProtocol = profile.psiphonProtocol,
                    psiphonCdnEdgeIps = profile.psiphonCdnEdgeIps,
                    psiphonCdnSni = profile.psiphonCdnSni,
                    enabled = enabled, edit = edit,
                )
                if (profile.chain.usesSstp) {
                    Spacer(Modifier.height(32.dp))
                    SstpDestination(config = profile.sstpConfig, enabled = enabled, edit = edit)
                }
            }
            SettingsPage.BRIDGES -> BridgeSection(
                bridgeMode = profile.torBridgeMode, transport = profile.torBridgeTransport,
                bridgeLines = profile.torBridgeLines, chain = profile.chain,
                enabled = enabled, edit = edit, fetchEdit = fetchEdit,
            )
            SettingsPage.TRANSPORT -> {
                TransportSection(
                    noize = profile.noize, keepalive = profile.keepalive, mtu = profile.mtu,
                    fragment = profile.fragment, fragmentSize = profile.fragmentSize,
                    fragmentDelay = profile.fragmentDelay, ech = profile.ech,
                    quicV2Opener = profile.quicV2Opener,
                    socketMark = profile.socketMark,
                    protocol = profile.protocol, masqueHttp2 = profile.masqueHttp2,
                    spoofMode = profile.spoofMode, spoofSni = profile.spoofSni,
                    enabled = enabled, edit = edit,
                )
                Hint(stringResource(R.string.settings_expert_note))
            }
            SettingsPage.ROUTING -> {
                RoutingSection(
                    proxyMode = profile.proxyMode, splitMode = profile.splitMode,
                    splitAppCount = profile.splitApps.size, blockedAppCount = profile.blockedApps.size,
                    enabled = enabled, edit = edit,
                    onPickSplitApps = { picker = AppPicker.SPLIT },
                    onPickBlockedApps = { picker = AppPicker.BLOCKED },
                )
                Spacer(Modifier.height(32.dp))
                RoutesSection(
                    routeBlock = profile.routeBlock, routeDirect = profile.routeDirect,
                    enabled = enabled, edit = edit,
                )
            }
            SettingsPage.SECURITY -> {
                SafetySection(
                    quickReconnect = profile.quickReconnect, killSwitch = profile.killSwitch,
                    strictKillSwitch = profile.strictKillSwitch, enabled = enabled, edit = edit,
                )
                Spacer(Modifier.height(32.dp))
                ResilienceSection(
                    ipv6LeakProtection = profile.ipv6LeakProtection, smartReconnect = profile.smartReconnect,
                    reconnectRetryLimit = profile.reconnectRetryLimit, enabled = enabled, edit = edit,
                )
            }
            SettingsPage.ORGANIZATION -> ZeroTrustSection(
                teamAuth = profile.teamAuth, team = profile.team,
                accessClientId = profile.accessClientId, accessClientSecret = profile.accessClientSecret,
                accessEmail = profile.accessEmail, accessToken = profile.accessToken,
                gateway = profile.gateway, enabled = enabled, edit = edit,
            )
            SettingsPage.TUNING -> {
                EngineTuningSection(
                    tlsGroups = profile.tlsGroups, validateSecs = profile.validateSecs,
                    reconnectSecs = profile.reconnectSecs, noDataCheck = profile.noDataCheck,
                    noProfileRetry = profile.noProfileRetry, coreLogLevel = profile.coreLogLevel,
                    enabled = enabled, edit = edit,
                )
                Spacer(Modifier.height(32.dp))
                CoreResourceSection(
                    maxClients = profile.maxClients, halfCloseSecs = profile.halfCloseSecs,
                    tcpKeepaliveSecs = profile.tcpKeepaliveSecs,
                    tcpConnectSecs = profile.tcpConnectSecs,
                    enabled = enabled, edit = edit,
                )
                Hint(stringResource(R.string.settings_expert_note))
            }
            SettingsPage.RESET -> ResetSection(enabled = enabled, edit = edit)
            SettingsPage.SHARING, SettingsPage.APPEARANCE, SettingsPage.AUTOMATION,
            SettingsPage.HISTORY, SettingsPage.SETUPS, SettingsPage.ABOUT -> Unit
        }
    }
    picker?.let { target ->
        AppPickerDialog(
            selected = if (target == AppPicker.SPLIT) profile.splitApps else profile.blockedApps,
            onDismiss = { picker = null },
            onConfirm = { apps ->
                if (enabled) {
                    edit { if (target == AppPicker.SPLIT) copy(splitApps = apps) else copy(blockedApps = apps) }
                }
                picker = null
            },
        )
    }
}
