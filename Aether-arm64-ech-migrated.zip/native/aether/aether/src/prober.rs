use std::collections::{HashMap, HashSet};
use std::net::{IpAddr, Ipv4Addr, Ipv6Addr, SocketAddr};
use std::sync::Arc;
use std::time::{Duration, Instant};

use futures::stream::StreamExt;
use rand::RngExt;

use crate::error::{AetherError, Result};
use crate::noize::NoizeConfig;
use crate::quic;

pub const MASQUE_DOCUMENTED_CIDRS_V4: &[&str] = &["162.159.197.0/24", "162.159.198.0/24"];

pub const MASQUE_DOH_CIDRS_V4: &[&str] = &["162.159.36.0/24", "162.159.46.0/24"];

pub const MASQUE_CIDRS_V4: &[&str] = &[
    "162.159.196.0/24",
    "162.159.195.0/24",
    "162.159.192.0/24",
    "162.159.193.0/24",
    "162.159.204.0/24",
    "162.159.197.0/24",
    "162.159.198.0/24",
    "172.65.251.0/24",
    "188.114.96.0/24",
    "188.114.97.0/24",
    "188.114.98.0/24",
    "188.114.99.0/24",
    "162.159.36.0/24",
    "162.159.46.0/24",
];

pub const MASQUE_SEEDS: &[&str] = &[
    "162.159.196.1",
    "162.159.195.1",
    "162.159.192.1",
    "162.159.197.3",
    "162.159.197.1",
    "162.159.198.2",
    "162.159.198.1",
    "162.159.193.1",
];

pub const MASQUE_VERIFIED_GATEWAYS: &[&str] = &[
    "162.159.199.1",
    "162.159.199.2",
    "162.159.198.2",
    "162.159.198.1",
];

pub const MASQUE_ALT_PORTS: &[u16] = &[1701, 8095, 500, 4500];

pub const MASQUE_PORTS: &[u16] = &[443, 500, 1701, 4500, 4443, 8443, 8095];

pub const MASQUE_CIDRS_V6: &[&str] = &[
    "2606:4700:d0::/48",
    "2606:4700:102::/48",
    "2606:4700:d1::/48",
];

pub const MASQUE_ZT_CIDRS_V4: &[&str] = &["162.159.197.0/24"];

pub const MASQUE_ZT_CIDRS_V6: &[&str] = &["2606:4700:102::/48"];

pub fn zero_trust_mode() -> bool {
    std::env::var("AETHER_TEAM")
        .map(|value| !value.trim().is_empty())
        .unwrap_or(false)
}

pub fn prioritize(all: &[&'static str], first: &[&'static str]) -> Vec<&'static str> {
    if !zero_trust_mode() {
        return all.to_vec();
    }

    let mut out: Vec<&'static str> = Vec::with_capacity(all.len());
    for entry in first {
        if all.contains(entry) {
            out.push(entry);
        }
    }
    for entry in all {
        if !out.contains(entry) {
            out.push(entry);
        }
    }
    out
}

pub fn masque_cidrs_v4() -> Vec<&'static str> {
    prioritize(MASQUE_CIDRS_V4, MASQUE_ZT_CIDRS_V4)
}

pub fn masque_cidrs_v6() -> Vec<&'static str> {
    prioritize(MASQUE_CIDRS_V6, MASQUE_ZT_CIDRS_V6)
}

pub const MASQUE_SEEDS_V6: &[&str] = &[
    "2606:4700:d0::a29f:c602",
    "2606:4700:d1::a29f:c602",
    "2606:4700:d0::a29f:c601",
    "2606:4700:d0::a29f:c001",
];

// ------------------------------------------------------------ user ranges
//
// Aether Mobile patch (perf/fast-connect): MANUAL RANGES ARE HONOURED AGAIN.
// The app hands the user's "Manual range" (and Smart Auto's probe-narrowed
// rungs) to the engine as AETHER_MASQUE_CIDRS / AETHER_WG_CIDRS /
// AETHER_SCAN_CIDRS. The patch that read them (prober/scan.rs) was dropped by
// the core 2.0.0 sync, so ever since then the setting promised a faster,
// narrower scan while the candidate builders swept the hard-coded ranges
// anyway. When any usable range is set, the sweep is now ONLY those ranges.

/// Most hosts taken from one user IPv4 range per sweep. A /24 is swept whole
/// (in random order); a wider range is sampled.
pub const USER_RANGE_MAX_HOSTS_V4: usize = 1024;

/// Hosts sampled from one user IPv6 range per sweep.
pub const USER_RANGE_MAX_HOSTS_V6: usize = 256;

/// Address ranges the user asked the scanner to stay inside, normalised to
/// `base/prefix` with the host bits cleared.
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct UserRanges {
    pub v4: Vec<String>,
    pub v6: Vec<String>,
}

impl UserRanges {
    pub fn is_empty(&self) -> bool {
        self.v4.is_empty() && self.v6.is_empty()
    }

    pub fn describe(&self) -> String {
        self.v4
            .iter()
            .chain(self.v6.iter())
            .cloned()
            .collect::<Vec<_>>()
            .join(", ")
    }
}

/// The user's ranges for one transport: `primary` (AETHER_MASQUE_CIDRS or
/// AETHER_WG_CIDRS) first, then the shared AETHER_SCAN_CIDRS. Empty when
/// neither holds a usable range, which means "the built-in ranges".
pub fn user_ranges_from_env(primary: &str) -> UserRanges {
    for key in [primary, "AETHER_SCAN_CIDRS"] {
        let Ok(raw) = std::env::var(key) else {
            continue;
        };
        let parsed = parse_user_ranges(&raw);
        if !parsed.is_empty() {
            return parsed;
        }
        if !raw.trim().is_empty() {
            log::warn!(
                "[-] {key}='{}' holds no usable range; scanning the built-in ranges",
                raw.trim()
            );
        }
    }
    UserRanges::default()
}

/// Parses a list separated by commas, semicolons or whitespace. Accepted:
/// `188.114.96.0/24`, `8.6.112.x` (or `*`; trailing octets only), a single
/// address such as `162.159.192.7`, and IPv6 CIDRs or addresses. Anything else
/// is logged and skipped.
pub fn parse_user_ranges(raw: &str) -> UserRanges {
    let mut out = UserRanges::default();
    for token in raw.split(|c: char| c == ',' || c == ';' || c.is_whitespace()) {
        let token = token.trim();
        if token.is_empty() {
            continue;
        }
        if let Some(cidr) = normalize_v4_range(token) {
            if !out.v4.contains(&cidr) {
                out.v4.push(cidr);
            }
        } else if let Some(cidr) = normalize_v6_range(token) {
            if !out.v6.contains(&cidr) {
                out.v6.push(cidr);
            }
        } else {
            log::warn!("[-] ignoring unreadable scan range '{token}'");
        }
    }
    out
}

fn normalize_v4_range(token: &str) -> Option<String> {
    let (addr, prefix) = match token.split_once('/') {
        Some((a, p)) => (a, Some(p.trim().parse::<u8>().ok().filter(|p| *p <= 32)?)),
        None => (token, None),
    };
    let parts: Vec<&str> = addr.trim().split('.').collect();
    if parts.len() != 4 {
        return None;
    }
    let mut octets = [0u8; 4];
    let mut wild_from: Option<usize> = None;
    for (i, part) in parts.iter().enumerate() {
        let part = part.trim();
        if part.eq_ignore_ascii_case("x") || part == "*" {
            if wild_from.is_none() {
                wild_from = Some(i);
            }
            continue;
        }
        if wild_from.is_some() {
            // A fixed octet after a wildcard is not a range.
            return None;
        }
        octets[i] = part.parse::<u8>().ok()?;
    }
    let bits: u8 = match (wild_from, prefix) {
        (Some(_), Some(_)) => return None,
        (Some(i), None) => (i as u8) * 8,
        (None, Some(p)) => p,
        (None, None) => 32,
    };
    if bits == 0 {
        // "Everything" is not a range anybody means to scan.
        return None;
    }
    let base = u32::from(Ipv4Addr::from(octets));
    let mask = if bits >= 32 {
        u32::MAX
    } else {
        u32::MAX << (32 - u32::from(bits))
    };
    Some(format!("{}/{}", Ipv4Addr::from(base & mask), bits))
}

fn normalize_v6_range(token: &str) -> Option<String> {
    let (addr, prefix) = match token.split_once('/') {
        Some((a, p)) => (
            a,
            p.trim().parse::<u8>().ok().filter(|p| *p > 0 && *p <= 128)?,
        ),
        None => (token, 128),
    };
    let addr = addr.trim().trim_start_matches('[').trim_end_matches(']');
    let base = u128::from(addr.parse::<Ipv6Addr>().ok()?);
    let mask = if prefix >= 128 {
        u128::MAX
    } else {
        u128::MAX << (128 - u32::from(prefix))
    };
    Some(format!("{}/{}", Ipv6Addr::from(base & mask), prefix))
}

/// Hosts to probe in one user IPv4 range, in random order: every host of a
/// range up to [`USER_RANGE_MAX_HOSTS_V4`], a sample of a wider one.
pub fn user_range_hosts_v4(cidr: &str) -> Vec<Ipv4Addr> {
    let Some((base, prefix)) = parse_cidr_v4(cidr) else {
        return Vec::new();
    };
    match 32u32.saturating_sub(u32::from(prefix)) {
        0 => vec![Ipv4Addr::from(base)],
        1 => vec![Ipv4Addr::from(base), Ipv4Addr::from(base.wrapping_add(1))],
        _ => sample_cidr_v4(cidr, USER_RANGE_MAX_HOSTS_V4),
    }
}

/// Up to `n` distinct random hosts inside one user IPv6 range.
pub fn user_range_hosts_v6(cidr: &str, n: usize) -> Vec<Ipv6Addr> {
    let Some((base, prefix)) = parse_cidr_v6(cidr) else {
        return Vec::new();
    };
    let host_bits = 128u32.saturating_sub(u32::from(prefix));
    if host_bits == 0 {
        return vec![Ipv6Addr::from(base)];
    }
    let host_mask: u128 = if host_bits >= 128 {
        u128::MAX
    } else {
        (1u128 << host_bits) - 1
    };
    let cap = if host_bits < 16 {
        n.min(1usize << host_bits)
    } else {
        n
    };
    let mut rng = rand::rng();
    let mut seen: HashSet<u128> = HashSet::with_capacity(cap);
    let mut out = Vec::with_capacity(cap);
    let mut tries = 0usize;
    while out.len() < cap && tries < cap.saturating_mul(8) {
        tries += 1;
        let host = rng.random::<u128>() & host_mask;
        if seen.insert(host) {
            out.push(Ipv6Addr::from((base & !host_mask) | host));
        }
    }
    out
}

/// The MASQUE sweep over the user's ranges only: every host on the primary
/// port first (ranges interleaved), then the other ports.
pub(crate) fn build_user_candidates(
    user: &UserRanges,
    ports: &[u16],
    ip: IpScan,
) -> Vec<(IpAddr, u16)> {
    let primary = ports.first().copied().unwrap_or(443);
    let mut hosts: Vec<IpAddr> = Vec::new();

    if ip.want_v4() {
        let per: Vec<Vec<Ipv4Addr>> = user.v4.iter().map(|c| user_range_hosts_v4(c)).collect();
        let max_len = per.iter().map(|v| v.len()).max().unwrap_or(0);
        for i in 0..max_len {
            for range in &per {
                if let Some(a) = range.get(i) {
                    hosts.push(IpAddr::V4(*a));
                }
            }
        }
    }
    if ip.want_v6() {
        let per: Vec<Vec<Ipv6Addr>> = user
            .v6
            .iter()
            .map(|c| user_range_hosts_v6(c, USER_RANGE_MAX_HOSTS_V6))
            .collect();
        let max_len = per.iter().map(|v| v.len()).max().unwrap_or(0);
        for i in 0..max_len {
            for range in &per {
                if let Some(a) = range.get(i) {
                    hosts.push(IpAddr::V6(*a));
                }
            }
        }
    }

    let mut out: Vec<(IpAddr, u16)> = Vec::new();
    let mut seen: HashSet<(IpAddr, u16)> = HashSet::new();
    for host in &hosts {
        if seen.insert((*host, primary)) {
            out.push((*host, primary));
        }
    }
    for &port in ports {
        if port == primary {
            continue;
        }
        for host in &hosts {
            if seen.insert((*host, port)) {
                out.push((*host, port));
            }
        }
    }
    out
}

#[derive(Debug, Clone, Copy)]
pub struct ProbeResult {
    pub ip: IpAddr,
    pub port: u16,
    pub rtt: Duration,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum IpScan {
    V4,
    V6,
    Both,
}

impl IpScan {
    pub fn parse(s: &str) -> IpScan {
        match s.trim().to_lowercase().as_str() {
            "6" | "v6" | "ipv6" => IpScan::V6,
            "both" | "all" | "dual" => IpScan::Both,
            _ => IpScan::V4,
        }
    }

    pub fn label(&self) -> &'static str {
        match self {
            IpScan::V4 => "ipv4",
            IpScan::V6 => "ipv6",
            IpScan::Both => "dual-stack",
        }
    }

    pub fn want_v4(&self) -> bool {
        matches!(self, IpScan::V4 | IpScan::Both)
    }

    pub fn want_v6(&self) -> bool {
        matches!(self, IpScan::V6 | IpScan::Both)
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ScanMode {
    Turbo,
    Balanced,
    Thorough,
    Verified,
    Ironclad,
}

impl ScanMode {
    pub fn parse(s: &str) -> ScanMode {
        match s.trim().to_lowercase().as_str() {
            "turbo" | "fast" => ScanMode::Turbo,
            "thorough" | "deep" | "pro" => ScanMode::Thorough,
            "verified" | "proven" | "stealth" | "quiet" => ScanMode::Verified,
            "ironclad" | "real" | "verify" | "guaranteed" => ScanMode::Ironclad,
            _ => ScanMode::Balanced,
        }
    }

    pub fn label(&self) -> &'static str {
        match self {
            ScanMode::Turbo => "turbo",
            ScanMode::Balanced => "balanced",
            ScanMode::Thorough => "thorough",
            ScanMode::Verified => "verified",
            ScanMode::Ironclad => "ironclad",
        }
    }

    /// Aether Mobile patch (perf/fast-connect): the quiet windows of the modes
    /// with a target are a few seconds now. Balanced waited 20 s of silence
    /// after EVERY new gateway (up to six), so the first healthy gateway could
    /// not be used for 20 s or more, and on a network where one edge answers
    /// that was pure wait. A better gateway that answers in the same burst is
    /// still preferred.
    fn strategy(&self) -> Strategy {
        match self {
            ScanMode::Turbo => Strategy {
                concurrency: 20,
                per_probe_timeout: Duration::from_millis(6000),
                overall_deadline: Duration::from_secs(45),
                quiet_after_first: Duration::from_secs(0),
                target_successes: 1,
                early_exit_first: true,
                full_subnet: false,
                sample_per_cidr: 64,
            },
            ScanMode::Balanced => Strategy {
                concurrency: 16,
                per_probe_timeout: Duration::from_millis(6000),
                overall_deadline: Duration::from_secs(120),
                quiet_after_first: Duration::from_secs(3),
                target_successes: 6,
                early_exit_first: false,
                full_subnet: false,
                sample_per_cidr: 140,
            },
            ScanMode::Thorough => Strategy {
                concurrency: 20,
                per_probe_timeout: Duration::from_millis(10000),
                overall_deadline: Duration::from_secs(300),
                quiet_after_first: Duration::from_secs(30),
                target_successes: 0,
                early_exit_first: false,
                full_subnet: true,
                sample_per_cidr: 0,
            },
            ScanMode::Verified => Strategy {
                concurrency: 16,
                per_probe_timeout: Duration::from_millis(5000),
                overall_deadline: Duration::from_secs(60),
                quiet_after_first: Duration::from_secs(3),
                target_successes: 4,
                early_exit_first: false,
                full_subnet: false,
                sample_per_cidr: 48,
            },
            ScanMode::Ironclad => Strategy {
                concurrency: 4,
                per_probe_timeout: Duration::from_millis(15000),
                overall_deadline: Duration::from_secs(180),
                quiet_after_first: Duration::from_secs(5),
                target_successes: 3,
                early_exit_first: false,
                full_subnet: false,
                sample_per_cidr: 140,
            },
        }
    }
}

const IRONCLAD_TCPING_TIMEOUT: Duration = Duration::from_secs(10);

struct Strategy {
    concurrency: usize,
    per_probe_timeout: Duration,
    overall_deadline: Duration,
    quiet_after_first: Duration,
    target_successes: usize,
    early_exit_first: bool,
    full_subnet: bool,
    sample_per_cidr: usize,
}

/// What the collection loop in [`hunt_best_gateway`] does after its `found`-th
/// working gateway.
///
/// Aether Mobile patch (2026-09-24, fix/masque-scan). Upstream armed the quiet
/// window only once `target_successes` gateways had answered, so a scan that
/// found one to five gateways on a filtered network - the common case in the
/// field - sat out the whole `overall_deadline` (120 s on balanced) before it
/// used any of them, while the app was already counting down its own budget.
/// The window now starts at the first gateway and restarts with every new one
/// until the target is reached, which is what its name and the "no new
/// gateways recently" log line describe. From the target on nothing changes:
/// one final window, not stretched by later answers. Turbo (first answer wins)
/// and thorough (no target, sweep everything) behave exactly as before.
/// (perf/fast-connect then shortened the windows themselves; see strategy().)
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum AfterSuccess {
    /// Target reached and no quiet window configured: pick the best now.
    Stop,
    /// (Re)start the quiet window: finish once nothing new answers for this long.
    QuietFor(Duration),
    /// Past the target: keep the final window that is already running.
    KeepWindow,
    /// No target: keep sweeping until the overall deadline.
    Continue,
}

fn after_success(st: &Strategy, found: usize) -> AfterSuccess {
    if st.target_successes == 0 {
        return AfterSuccess::Continue;
    }
    let reached = found >= st.target_successes;
    if st.quiet_after_first.is_zero() {
        return if reached {
            AfterSuccess::Stop
        } else {
            AfterSuccess::Continue
        };
    }
    if found > st.target_successes {
        return AfterSuccess::KeepWindow;
    }
    AfterSuccess::QuietFor(st.quiet_after_first)
}

/// Why candidates failed, counted by reason.
///
/// Aether Mobile patch (fix/masque-scan-congestion). Every failed probe used to
/// be logged at trace only, so a scan that found nothing left a single "scan
/// deadline reached with no gateway" line and no way to tell a filtered range
/// from a refused CONNECT-IP, a TLS problem or a broken socket. The scan now
/// reports the most common reasons when it ends.
#[derive(Debug, Default)]
struct FailureTally {
    total: usize,
    reasons: HashMap<String, usize>,
}

/// Longest reason text kept per failure, so one odd error cannot flood the log.
const FAILURE_REASON_MAX_CHARS: usize = 120;

impl FailureTally {
    fn record(&mut self, reason: String) {
        self.total += 1;
        *self.reasons.entry(reason).or_insert(0) += 1;
    }

    /// The `top` most frequent reasons, most frequent first, as `"Nx reason"`.
    fn summary(&self, top: usize) -> String {
        let mut ranked: Vec<(&String, &usize)> = self.reasons.iter().collect();
        ranked.sort_by(|a, b| b.1.cmp(a.1).then_with(|| a.0.cmp(b.0)));
        ranked
            .into_iter()
            .take(top)
            .map(|(reason, count)| format!("{count}x {reason}"))
            .collect::<Vec<_>>()
            .join("; ")
    }
}

fn failure_reason(path: &str, error: &dyn std::fmt::Display) -> String {
    let text: String = error
        .to_string()
        .chars()
        .take(FAILURE_REASON_MAX_CHARS)
        .collect();
    format!("{path}: {text}")
}

#[derive(Clone)]
pub struct MasqueProbe {
    pub sni: String,
    pub authority: String,
    pub path: String,
    pub cert_pem: Arc<[u8]>,
    pub key_pem: Arc<[u8]>,
    pub ech_config_list: Option<Arc<[u8]>>,
    pub noize: NoizeConfig,
    pub ports: Vec<u16>,
    pub ip: IpScan,
    pub local_ipv4: Ipv4Addr,
}

pub async fn host_has_ipv6() -> bool {
    match crate::egress::udp_bind("[::]:0".parse().expect("a wildcard address")) {
        Ok(sock) => sock.connect("[2606:4700:d0::a29f:c001]:443").await.is_ok(),
        Err(_) => false,
    }
}

pub async fn hunt_best_gateway(probe: &MasqueProbe, mode: ScanMode) -> Result<ProbeResult> {
    let mut st = mode.strategy();
    st.concurrency = crate::sysprofile::cap_concurrency(st.concurrency);
    let timeout = st.per_probe_timeout;
    let mut effective_ip = probe.ip;
    if probe.ip.want_v6() && !host_has_ipv6().await {
        if probe.ip.want_v4() {
            log::warn!("[-] host has no IPv6 route; falling back to IPv4-only scan");
            effective_ip = IpScan::V4;
        } else {
            log::warn!("[-] host has no IPv6 route; IPv6 scan needs native IPv6 connectivity");
            return Err(AetherError::NoCleanEndpoint);
        }
    }
    let candidates = build_candidates(&st, &probe.ports, effective_ip);

    log::info!(
        "[*] scan mode={} ip={} candidates={} ports={:?} concurrency={} per_probe={:?} budget={:?}",
        mode.label(),
        effective_ip.label(),
        candidates.len(),
        probe.ports,
        st.concurrency,
        st.per_probe_timeout,
        st.overall_deadline,
    );

    let ironclad = mode == ScanMode::Ironclad;

    let stream = futures::stream::iter(
        candidates
            .into_iter()
            .map(|(ip, port)| verify_one(probe, ip, port, timeout, ironclad)),
    )
    .buffer_unordered(st.concurrency);
    tokio::pin!(stream);

    let deadline = Instant::now() + st.overall_deadline;
    let mut best: Option<ProbeResult> = None;
    let mut found = 0usize;
    let mut quiet_until: Option<Instant> = None;
    let mut failures = FailureTally::default();

    loop {
        let effective = match quiet_until {
            Some(q) => q.min(deadline),
            None => deadline,
        };
        let remaining = effective.saturating_duration_since(Instant::now());
        if remaining.is_zero() {
            if best.is_some() {
                if quiet_until.is_some() {
                    log::info!("[+] no new gateways recently, finalizing selection");
                } else {
                    log::warn!("[-] scan deadline reached");
                }
            } else {
                log::warn!("[-] scan deadline reached with no gateway");
            }
            break;
        }

        tokio::select! {
            item = stream.next() => {
                match item {
                    None => break,
                    Some(Err(reason)) => {
                        failures.record(reason);
                        continue;
                    }
                    Some(Ok(pr)) => {
                        log::info!("[+] candidate ok {}:{} rtt={:?}", pr.ip, pr.port, pr.rtt);
                        if st.early_exit_first {
                            return Ok(pr);
                        }
                        best = Some(match best {
                            Some(cur) if cur.rtt <= pr.rtt => cur,
                            _ => pr,
                        });
                        found += 1;

                        // Aether Mobile patch (fix/masque-scan): see after_success().
                        match after_success(&st, found) {
                            AfterSuccess::Stop => {
                                log::info!(
                                    "[+] reached target of {} gateways, selecting best",
                                    st.target_successes
                                );
                                break;
                            }
                            AfterSuccess::QuietFor(window) => {
                                if found == st.target_successes {
                                    log::info!(
                                        "[+] reached target of {} gateways, selecting best",
                                        st.target_successes
                                    );
                                } else if quiet_until.is_none() {
                                    log::info!(
                                        "[+] gateway found; finalizing once none new answers for {:?}",
                                        window
                                    );
                                }
                                quiet_until = Some(Instant::now() + window);
                            }
                            AfterSuccess::KeepWindow | AfterSuccess::Continue => {}
                        }
                    }
                }
            }
            _ = tokio::time::sleep(remaining) => {
                if best.is_some() {
                    if quiet_until.is_some() {
                        log::info!("[+] no new gateways recently, finalizing selection");
                    } else {
                        log::warn!("[-] scan deadline reached");
                    }
                } else {
                    log::warn!("[-] scan deadline reached with no gateway");
                }
                break;
            }
        }
    }

    match best {
        Some(pr) => {
            if failures.total > 0 {
                log::debug!(
                    "[*] {} candidate(s) failed along the way: {}",
                    failures.total,
                    failures.summary(3)
                );
            }
            log::info!("[+] best gateway {}:{} rtt={:?}", pr.ip, pr.port, pr.rtt);
            Ok(pr)
        }
        None => {
            if failures.total > 0 {
                log::warn!(
                    "[-] {} candidate(s) failed; most common reasons: {}",
                    failures.total,
                    failures.summary(3)
                );
            } else {
                log::warn!("[-] no candidate finished inside the scan budget");
            }
            Err(AetherError::NoCleanEndpoint)
        }
    }
}

async fn verify_one(
    probe: &MasqueProbe,
    ip: IpAddr,
    port: u16,
    timeout: Duration,
    ironclad: bool,
) -> std::result::Result<ProbeResult, String> {
    if ironclad {
        let params = crate::tunnelping::MasquePingParams {
            peer: SocketAddr::new(ip, port),
            sni: probe.sni.clone(),
            authority: probe.authority.clone(),
            path: probe.path.clone(),
            cert_pem: probe.cert_pem.to_vec(),
            key_pem: probe.key_pem.to_vec(),
            noize: probe.noize.clone(),
            local_ipv4: probe.local_ipv4,
            local_ipv4_str: probe.local_ipv4.to_string(),
            local_ipv6_str: String::new(),
        };
        return match crate::tunnelping::masque_http_ping(&params, IRONCLAD_TCPING_TIMEOUT).await {
            Ok(rtt) => {
                log::info!(
                    "[+] ironclad verified {ip}:{port} real http round trip rtt={:?}",
                    rtt
                );
                Ok(ProbeResult { ip, port, rtt })
            }
            Err(e) => {
                log::trace!("[-] ironclad {ip}:{port} failed real http check: {e}");
                Err(failure_reason("ironclad", &e))
            }
        };
    }

    if crate::masque_h2::enabled() {
        let cfg = crate::masque_h2::H2TunnelConfig {
            peer: SocketAddr::new(ip, port),
            sni: probe.sni.clone(),
            authority: probe.authority.clone(),
            path: probe.path.clone(),
            cert_pem: probe.cert_pem.to_vec(),
            key_pem: probe.key_pem.to_vec(),
            local_ipv4: probe.local_ipv4,
            quiet: true,
            pin_endpoint: true,
            expected_pins: crate::consts::MASQUE_PINS
                .iter()
                .map(|p| p.to_vec())
                .collect(),
        };
        return match crate::masque_h2::verify_h2(&cfg, timeout).await {
            Ok(rtt) => Ok(ProbeResult { ip, port, rtt }),
            Err(e) => {
                log::trace!("h2 probe {ip}:{port} -> {e}");
                Err(failure_reason("h2", &e))
            }
        };
    }

    let vp = quic::VerifyParams {
        peer: SocketAddr::new(ip, port),
        sni: probe.sni.clone(),
        authority: probe.authority.clone(),
        path: probe.path.clone(),
        cert_pem: probe.cert_pem.to_vec(),
        key_pem: probe.key_pem.to_vec(),
        ech_config_list: probe.ech_config_list.as_ref().map(|a| a.to_vec()),
        noize: probe.noize.clone(),
        timeout,
        local_ipv4: probe.local_ipv4,
    };

    match quic::verify_masque(&vp).await {
        Ok(rtt) => Ok(ProbeResult { ip, port, rtt }),
        Err(e) => {
            log::trace!("probe {ip}:{port} -> {e}");
            Err(failure_reason("quic", &e))
        }
    }
}

fn build_candidates(st: &Strategy, ports: &[u16], ip: IpScan) -> Vec<(IpAddr, u16)> {
    // Aether Mobile patch (perf/fast-connect): the user's own ranges, when
    // set, replace the built-in sweep entirely (see "user ranges" above).
    let user = user_ranges_from_env("AETHER_MASQUE_CIDRS");
    if !user.is_empty() {
        let out = build_user_candidates(&user, ports, ip);
        log::info!(
            "[*] masque scan restricted to your ranges: {} ({} candidates)",
            user.describe(),
            out.len()
        );
        if out.is_empty() {
            log::warn!(
                "[-] none of your ranges match the {} scan; nothing to probe",
                ip.label()
            );
        }
        return out;
    }

    let primary = ports.first().copied().unwrap_or(443);
    let mut out: Vec<(IpAddr, u16)> = Vec::new();
    let mut seen: HashSet<(IpAddr, u16)> = HashSet::new();

    let seeds: Vec<Ipv4Addr> = MASQUE_SEEDS.iter().filter_map(|s| s.parse().ok()).collect();
    let seeds6: Vec<Ipv6Addr> = MASQUE_SEEDS_V6
        .iter()
        .filter_map(|s| s.parse().ok())
        .collect();

    // Aether Mobile patch (2026-09-24, fix/masque-scan): the DNS-over-HTTPS
    // ranges never serve MASQUE, which is why MASQUE_CIDRS_V4 lists them last
    // (see the tests below). The round-robin sweep still gave them 2 of every
    // 14 probes from the very first round, so they are now queued after every
    // other candidate instead. Nothing is dropped.
    let (sweep_v4, doh_v4): (Vec<&'static str>, Vec<&'static str>) = masque_cidrs_v4()
        .into_iter()
        .partition(|c| !MASQUE_DOH_CIDRS_V4.contains(c));

    if ip.want_v4() {
        for a in &seeds {
            if seen.insert((IpAddr::V4(*a), primary)) {
                out.push((IpAddr::V4(*a), primary));
            }
        }
        push_interleaved_v4(st, &sweep_v4, primary, &mut seen, &mut out);
    }

    if ip.want_v6() {
        for a in &seeds6 {
            if seen.insert((IpAddr::V6(*a), primary)) {
                out.push((IpAddr::V6(*a), primary));
            }
        }
        let per = if st.sample_per_cidr == 0 {
            96
        } else {
            st.sample_per_cidr
        };
        let cidr6: Vec<Vec<Ipv6Addr>> = masque_cidrs_v6()
            .iter()
            .map(|c| sample_cidr_v6(c, per, MASQUE_CIDRS_V4))
            .collect();
        let max6 = cidr6.iter().map(|v| v.len()).max().unwrap_or(0);
        for i in 0..max6 {
            for hosts in &cidr6 {
                if let Some(a) = hosts.get(i) {
                    if seen.insert((IpAddr::V6(*a), primary)) {
                        out.push((IpAddr::V6(*a), primary));
                    }
                }
            }
        }
    }

    if ip.want_v4() {
        for a in &seeds {
            for &port in ports {
                if port != primary && seen.insert((IpAddr::V4(*a), port)) {
                    out.push((IpAddr::V4(*a), port));
                }
            }
        }
    }
    if ip.want_v6() {
        for a in &seeds6 {
            for &port in ports {
                if port != primary && seen.insert((IpAddr::V6(*a), port)) {
                    out.push((IpAddr::V6(*a), port));
                }
            }
        }
    }

    if ip.want_v4() {
        push_interleaved_v4(st, &doh_v4, primary, &mut seen, &mut out);
    }

    out
}

/// Samples (or, on a full-subnet strategy, enumerates) every range in `cidrs`
/// and queues the hosts round-robin, one per range per round, skipping any
/// address already queued. Aether Mobile patch (fix/masque-scan): the body of
/// upstream's v4 sweep, lifted out so it can run twice.
fn push_interleaved_v4(
    st: &Strategy,
    cidrs: &[&str],
    port: u16,
    seen: &mut HashSet<(IpAddr, u16)>,
    out: &mut Vec<(IpAddr, u16)>,
) {
    let cidr_hosts: Vec<Vec<Ipv4Addr>> = cidrs
        .iter()
        .map(|c| {
            if st.full_subnet {
                enumerate_cidr_v4(c)
            } else {
                sample_cidr_v4(c, st.sample_per_cidr)
            }
        })
        .collect();
    let max_len = cidr_hosts.iter().map(|v| v.len()).max().unwrap_or(0);
    for i in 0..max_len {
        for hosts in &cidr_hosts {
            if let Some(a) = hosts.get(i) {
                if seen.insert((IpAddr::V4(*a), port)) {
                    out.push((IpAddr::V4(*a), port));
                }
            }
        }
    }
}

fn parse_cidr_v4(cidr: &str) -> Option<(u32, u8)> {
    let (ip, prefix) = cidr.split_once('/')?;
    Some((
        u32::from(ip.parse::<Ipv4Addr>().ok()?),
        prefix.parse().ok()?,
    ))
}

fn enumerate_cidr_v4(cidr: &str) -> Vec<Ipv4Addr> {
    let (base, prefix) = match parse_cidr_v4(cidr) {
        Some(v) => v,
        None => return Vec::new(),
    };
    let host_bits = 32u32.saturating_sub(prefix as u32);
    if host_bits == 0 {
        return vec![Ipv4Addr::from(base)];
    }
    if host_bits > 12 {
        return Vec::new();
    }
    let size = 1u32 << host_bits;
    (1..size.saturating_sub(1))
        .map(|off| Ipv4Addr::from(base + off))
        .collect()
}

fn sample_cidr_v4(cidr: &str, n: usize) -> Vec<Ipv4Addr> {
    let (base, prefix) = match parse_cidr_v4(cidr) {
        Some(v) => v,
        None => return Vec::new(),
    };
    let host_bits = 32u32.saturating_sub(prefix as u32);
    let size = if host_bits >= 32 {
        u32::MAX
    } else {
        1u32 << host_bits
    };
    if size <= 2 {
        return vec![Ipv4Addr::from(base)];
    }

    let usable = size - 2;
    let want = (n as u32).min(usable);
    let mut rng = rand::rng();
    let mut chosen: HashSet<u32> = HashSet::with_capacity(want as usize);
    let mut out = Vec::with_capacity(want as usize);

    while (out.len() as u32) < want {
        let off = 1 + rng.random_range(0..usable);
        if chosen.insert(off) {
            out.push(Ipv4Addr::from(base + off));
        }
    }

    out
}

fn parse_cidr_v6(cidr: &str) -> Option<(u128, u8)> {
    let (ip, prefix) = cidr.split_once('/')?;
    Some((
        u128::from(ip.parse::<Ipv6Addr>().ok()?),
        prefix.parse().ok()?,
    ))
}

fn sample_cidr_v6(cidr: &str, n: usize, v4_cidrs: &[&str]) -> Vec<Ipv6Addr> {
    let (base, prefix) = match parse_cidr_v6(cidr) {
        Some(v) => v,
        None => return Vec::new(),
    };
    if 128u32.saturating_sub(prefix as u32) == 0 {
        return vec![Ipv6Addr::from(base)];
    }

    let v4: Vec<(u32, u8)> = v4_cidrs.iter().filter_map(|c| parse_cidr_v4(c)).collect();
    let mut rng = rand::rng();
    let mut out = Vec::with_capacity(n);
    for _ in 0..n {
        let embedded = if v4.is_empty() {
            rng.random::<u32>() as u128
        } else {
            let (b, p) = v4[rng.random_range(0..v4.len())];
            let host_bits = 32u32.saturating_sub(p as u32);
            let host = if host_bits == 0 {
                0
            } else {
                rng.random::<u32>() & ((1u32 << host_bits) - 1)
            };
            (b | host) as u128
        };
        out.push(Ipv6Addr::from(base | embedded));
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn the_documented_zero_trust_masque_ingress_range_is_scanned() {
        assert!(MASQUE_CIDRS_V4.contains(&"162.159.197.0/24"));
        assert!(MASQUE_CIDRS_V6.contains(&"2606:4700:102::/48"));
    }

    #[test]
    fn the_dns_over_https_ranges_are_swept_last_because_they_never_serve_masque() {
        let tail = &MASQUE_CIDRS_V4[MASQUE_CIDRS_V4.len() - MASQUE_DOH_CIDRS_V4.len()..];
        for entry in MASQUE_DOH_CIDRS_V4 {
            assert!(tail.contains(entry), "{entry} should be at the end");
        }
    }

    fn in_cidr_v4(ip: Ipv4Addr, cidr: &str) -> bool {
        let (base, prefix) = parse_cidr_v4(cidr).expect("cidr");
        let mask = if prefix == 0 {
            0
        } else {
            u32::MAX << (32 - u32::from(prefix))
        };
        (u32::from(ip) & mask) == (base & mask)
    }

    fn is_doh(ip: &IpAddr) -> bool {
        match ip {
            IpAddr::V4(v4) => MASQUE_DOH_CIDRS_V4.iter().any(|c| in_cidr_v4(*v4, c)),
            IpAddr::V6(_) => false,
        }
    }

    fn assert_doh_swept_last(mode: ScanMode) {
        let candidates = build_candidates(&mode.strategy(), MASQUE_PORTS, IpScan::V4);
        let first_doh = candidates
            .iter()
            .position(|(ip, _)| is_doh(ip))
            .expect("the dns-over-https ranges are still swept, only last");
        assert!(first_doh > 0, "{}: the sweep opens with them", mode.label());
        assert!(
            candidates[first_doh..].iter().all(|(ip, _)| is_doh(ip)),
            "{}: a candidate outside the dns-over-https ranges is queued behind them",
            mode.label()
        );
    }

    #[test]
    fn the_dns_over_https_ranges_are_probed_after_every_other_candidate() {
        assert_doh_swept_last(ScanMode::Turbo);
        assert_doh_swept_last(ScanMode::Balanced);
        assert_doh_swept_last(ScanMode::Verified);
        assert_doh_swept_last(ScanMode::Ironclad);
        assert_doh_swept_last(ScanMode::Thorough);
    }

    fn assert_quiet_window_after_every_gateway(mode: ScanMode) {
        let st = mode.strategy();
        assert!(st.target_successes > 1, "{}", mode.label());
        assert!(!st.quiet_after_first.is_zero(), "{}", mode.label());
        for found in 1..=st.target_successes {
            assert_eq!(
                after_success(&st, found),
                AfterSuccess::QuietFor(st.quiet_after_first),
                "{} after {found} gateway(s)",
                mode.label()
            );
        }
        assert_eq!(
            after_success(&st, st.target_successes + 1),
            AfterSuccess::KeepWindow,
            "{}: the final window is not stretched past the target",
            mode.label()
        );
    }

    #[test]
    fn a_scan_with_a_target_stops_waiting_once_the_edge_goes_quiet_after_a_gateway() {
        assert_quiet_window_after_every_gateway(ScanMode::Balanced);
        assert_quiet_window_after_every_gateway(ScanMode::Verified);
        assert_quiet_window_after_every_gateway(ScanMode::Ironclad);
    }

    #[test]
    fn turbo_still_takes_the_first_gateway_and_thorough_still_sweeps_to_the_end() {
        assert_eq!(after_success(&ScanMode::Turbo.strategy(), 1), AfterSuccess::Stop);
        let thorough = ScanMode::Thorough.strategy();
        for found in [1, 5, 50] {
            assert_eq!(after_success(&thorough, found), AfterSuccess::Continue);
        }
    }

    #[test]
    fn every_quiet_window_is_shorter_than_its_deadline() {
        for mode in [ScanMode::Balanced, ScanMode::Verified, ScanMode::Ironclad] {
            let st = mode.strategy();
            assert!(st.quiet_after_first < st.overall_deadline, "{}", mode.label());
        }
    }

    /// perf/fast-connect: the first healthy gateway is used within seconds.
    #[test]
    fn balanced_and_verified_settle_within_seconds_of_a_gateway() {
        for mode in [ScanMode::Balanced, ScanMode::Verified] {
            assert!(
                mode.strategy().quiet_after_first <= Duration::from_secs(5),
                "{}",
                mode.label()
            );
        }
    }

    #[test]
    fn user_ranges_accept_cidrs_wildcards_and_single_addresses() {
        let parsed = parse_user_ranges(
            "188.114.96.5/24, 8.6.112.x;162.159.192.7\n10.1.x.x  2606:4700:d0::/48 junk 1.2.3.4/40 x.x.x.x 8.6.x.5",
        );
        assert_eq!(
            parsed.v4,
            vec!["188.114.96.0/24", "8.6.112.0/24", "162.159.192.7/32", "10.1.0.0/16"]
        );
        assert_eq!(parsed.v6, vec!["2606:4700:d0::/48"]);
        assert!(parse_user_ranges("  ,; ").is_empty());
    }

    #[test]
    fn user_ranges_replace_the_built_in_sweep() {
        let user = parse_user_ranges("188.114.97.0/30, 162.159.192.9");
        let candidates = build_user_candidates(&user, &[443, 500], IpScan::V4);
        assert_eq!(candidates.len(), 6, "{candidates:?}");
        assert!(
            candidates[..3].iter().all(|(_, port)| *port == 443),
            "every address is tried on the primary port first"
        );
        assert!(candidates.iter().all(|(ip, _)| match ip {
            IpAddr::V4(v4) => {
                in_cidr_v4(*v4, "188.114.97.0/30") || *v4 == Ipv4Addr::new(162, 159, 192, 9)
            }
            IpAddr::V6(_) => false,
        }));
        assert!(
            candidates.iter().all(|(ip, _)| {
                let seed = ip.to_string();
                !MASQUE_SEEDS.contains(&seed.as_str())
            }),
            "no built-in seed may be probed when the user named ranges"
        );
    }

    #[test]
    fn user_ranges_of_the_other_family_yield_no_candidates() {
        let user = parse_user_ranges("2606:4700:d0::/120");
        assert!(build_user_candidates(&user, MASQUE_PORTS, IpScan::V4).is_empty());
        let v6 = build_user_candidates(&user, &[443], IpScan::V6);
        assert!(!v6.is_empty());
        assert!(v6.len() <= USER_RANGE_MAX_HOSTS_V6);
    }

    #[test]
    fn failed_candidates_are_summarised_most_common_first() {
        let mut tally = FailureTally::default();
        for _ in 0..3 {
            tally.record("quic: verify timeout".to_string());
        }
        tally.record("quic: status 403".to_string());
        for _ in 0..2 {
            tally.record("quic: closed before data-plane confirmation".to_string());
        }
        assert_eq!(tally.total, 6);
        assert_eq!(
            tally.summary(2),
            "3x quic: verify timeout; 2x quic: closed before data-plane confirmation"
        );
        assert!(FailureTally::default().summary(3).is_empty());
    }

    #[test]
    fn a_failure_reason_is_labelled_and_bounded() {
        let long = "x".repeat(FAILURE_REASON_MAX_CHARS * 3);
        let reason = failure_reason("h2", &long);
        assert!(reason.starts_with("h2: "));
        assert_eq!(reason.chars().count(), "h2: ".len() + FAILURE_REASON_MAX_CHARS);
    }

    #[test]
    fn the_documented_default_masque_port_leads_the_sweep() {
        assert_eq!(MASQUE_PORTS.first(), Some(&443));
    }

    #[test]
    fn the_documented_masque_fallback_ports_keep_their_documented_order() {
        assert_eq!(MASQUE_PORTS, &[443, 500, 1701, 4500, 4443, 8443, 8095]);
    }

    #[test]
    fn without_a_team_the_range_order_is_left_alone() {
        std::env::remove_var("AETHER_TEAM");
        assert_eq!(
            prioritize(MASQUE_CIDRS_V4, MASQUE_ZT_CIDRS_V4),
            MASQUE_CIDRS_V4.to_vec()
        );
    }

    #[test]
    fn prioritize_moves_the_wanted_entries_to_the_front_without_losing_any() {
        let all = ["a", "b", "c", "d"];
        let out = {
            let mut out: Vec<&'static str> = vec!["c"];
            for entry in all {
                if !out.contains(&entry) {
                    out.push(entry);
                }
            }
            out
        };
        assert_eq!(out, vec!["c", "a", "b", "d"]);
        assert_eq!(out.len(), all.len());
    }

    #[test]
    fn the_documented_masque_fallback_ports_are_all_covered() {
        for port in [443u16, 500, 1701, 4443, 4500, 8443, 8095] {
            assert!(
                MASQUE_PORTS.contains(&port),
                "documented fallback port {port} should be scanned"
            );
        }
    }

    async fn quic_answers(peer: SocketAddr, timeout: Duration) -> Option<Duration> {
        let bind = if peer.is_ipv4() {
            "0.0.0.0:0"
        } else {
            "[::]:0"
        };
        let sock = tokio::net::UdpSocket::bind(bind).await.ok()?;
        sock.connect(peer).await.ok()?;
        let local = sock.local_addr().ok()?;

        let mut config = quiche::Config::new(quiche::PROTOCOL_VERSION).ok()?;
        config.set_application_protos(&[b"h3"]).ok()?;
        config.verify_peer(false);
        config.set_max_idle_timeout(timeout.as_millis() as u64);
        config.set_initial_max_data(1_000_000);
        config.set_initial_max_stream_data_bidi_local(100_000);
        config.set_initial_max_streams_bidi(4);

        let mut scid = [0u8; 16];
        rand::rng().fill(&mut scid[..]);
        let scid = quiche::ConnectionId::from_ref(&scid);

        let sni = crate::consts::CONNECT_SNI;
        let mut conn = quiche::connect(Some(sni), &scid, local, peer, &mut config).ok()?;

        let mut out = [0u8; 1350];
        let (written, _) = conn.send(&mut out).ok()?;

        let started = Instant::now();
        sock.send(&out[..written]).await.ok()?;

        let mut buf = [0u8; 1500];
        match tokio::time::timeout(timeout, sock.recv(&mut buf)).await {
            Ok(Ok(read)) if read > 0 => Some(started.elapsed()),
            _ => None,
        }
    }

    async fn tcp_answers(peer: SocketAddr, timeout: Duration) -> Option<Duration> {
        let started = Instant::now();
        match tokio::time::timeout(timeout, tokio::net::TcpStream::connect(peer)).await {
            Ok(Ok(_)) => Some(started.elapsed()),
            _ => None,
        }
    }

    async fn first_answer(
        targets: &[SocketAddr],
        timeout: Duration,
        attempts: u32,
        udp: bool,
    ) -> Option<(SocketAddr, Duration)> {
        for _ in 0..attempts {
            let probes = targets.iter().copied().map(|peer| async move {
                let rtt = match udp {
                    true => quic_answers(peer, timeout).await,
                    false => tcp_answers(peer, timeout).await,
                };
                (peer, rtt)
            });

            let results: Vec<(SocketAddr, Option<Duration>)> = futures::stream::iter(probes)
                .buffer_unordered(targets.len().max(1))
                .collect()
                .await;

            if let Some((peer, Some(rtt))) = results.into_iter().find(|(_, rtt)| rtt.is_some()) {
                return Some((peer, rtt));
            }
        }
        None
    }

    fn hosts_of(cidr: &str, tails: &[u8]) -> Vec<Ipv4Addr> {
        let base: Ipv4Addr = cidr.split('/').next().unwrap().parse().expect("cidr base");
        let octets = base.octets();
        tails
            .iter()
            .map(|tail| Ipv4Addr::new(octets[0], octets[1], octets[2], *tail))
            .collect()
    }

    #[tokio::test(flavor = "multi_thread")]
    #[ignore = "probes the live cloudflare edge from this network to see which masque ranges answer"]
    async fn report_which_masque_ranges_answer_on_this_network() {
        const TAILS: &[u8] = &[1, 2, 3];

        let timeout = Duration::from_millis(
            std::env::var("AETHER_PROBE_TIMEOUT_MS")
                .ok()
                .and_then(|raw| raw.trim().parse::<u64>().ok())
                .filter(|ms| *ms > 0)
                .unwrap_or(10_000),
        );

        let attempts = std::env::var("AETHER_PROBE_ATTEMPTS")
            .ok()
            .and_then(|raw| raw.trim().parse::<u32>().ok())
            .filter(|n| *n > 0)
            .unwrap_or(2);

        let ports: Vec<u16> = match std::env::var("AETHER_PROBE_PORTS") {
            Ok(raw) => raw
                .split(',')
                .filter_map(|p| p.trim().parse::<u16>().ok())
                .collect(),
            Err(_) => vec![443],
        };
        let ports = if ports.is_empty() { vec![443] } else { ports };

        println!();
        println!("probing the masque ranges from this network");
        println!("  udp timeout {timeout:?}, {attempts} attempt(s), hosts {TAILS:?}");
        println!("  udp ports {ports:?}");
        println!("  override: AETHER_PROBE_TIMEOUT_MS, AETHER_PROBE_ATTEMPTS, AETHER_PROBE_PORTS");
        println!();

        let control: Vec<SocketAddr> = vec![
            "1.1.1.1:443".parse().unwrap(),
            "8.8.8.8:443".parse().unwrap(),
        ];

        let control_quic = first_answer(&control, timeout, attempts, true).await;
        let control_tcp = first_answer(&control, timeout, attempts, false).await;

        println!("control targets (public resolvers, not cloudflare warp edges)");
        match control_quic {
            Some((peer, rtt)) => println!("  quic/udp 443 works: {peer} in {}ms", rtt.as_millis()),
            None => println!("  quic/udp 443 got no answer at all"),
        }
        match control_tcp {
            Some((peer, rtt)) => println!("  tcp 443 works:      {peer} in {}ms", rtt.as_millis()),
            None => println!("  tcp 443 got no answer at all"),
        }
        println!();

        let mut udp_ok = Vec::new();
        let mut tcp_only = Vec::new();
        let mut silent = Vec::new();

        for cidr in MASQUE_CIDRS_V4 {
            let note = if MASQUE_DOCUMENTED_CIDRS_V4.contains(cidr) {
                " [documented]"
            } else if MASQUE_DOH_CIDRS_V4.contains(cidr) {
                " [dns-over-https]"
            } else {
                ""
            };

            let hosts = hosts_of(cidr, TAILS);

            let mut udp_hit: Option<(SocketAddr, Duration)> = None;
            for port in &ports {
                let targets: Vec<SocketAddr> = hosts
                    .iter()
                    .map(|ip| SocketAddr::new(IpAddr::V4(*ip), *port))
                    .collect();
                udp_hit = first_answer(&targets, timeout, attempts, true).await;
                if udp_hit.is_some() {
                    break;
                }
            }

            let tcp_targets: Vec<SocketAddr> = hosts
                .iter()
                .map(|ip| SocketAddr::new(IpAddr::V4(*ip), 443))
                .collect();
            let tcp_hit = first_answer(&tcp_targets, timeout, attempts, false).await;

            match (udp_hit, tcp_hit) {
                (Some((peer, rtt)), _) => {
                    println!("  UDP OK    {cidr}{note}  {peer} in {}ms", rtt.as_millis());
                    udp_ok.push(*cidr);
                }
                (None, Some((peer, rtt))) => {
                    println!(
                        "  TCP ONLY  {cidr}{note}  {peer} in {}ms, udp stayed silent",
                        rtt.as_millis()
                    );
                    tcp_only.push(*cidr);
                }
                (None, None) => {
                    println!("  SILENT    {cidr}{note}");
                    silent.push(*cidr);
                }
            }
        }

        println!();
        println!("masque over quic works on ({}):", udp_ok.len());
        for cidr in &udp_ok {
            println!("  {cidr}");
        }
        println!();
        println!("reachable over tcp only ({}):", tcp_only.len());
        for cidr in &tcp_only {
            println!("  {cidr}");
        }
        println!();
        println!("no answer on either ({}):", silent.len());
        for cidr in &silent {
            println!("  {cidr}");
        }

        println!();
        println!("verdict");
        if !udp_ok.is_empty() {
            println!("  put these ranges first in MASQUE_CIDRS_V4: {udp_ok:?}");
        } else if control_quic.is_none() {
            println!("  this network answers no quic at all, not even a public resolver,");
            println!("  so udp 443 is blocked here rather than these ranges being blocked.");
            println!("  reordering MASQUE_CIDRS_V4 cannot help; masque needs its http/2");
            println!("  fallback over tcp 443 (--masque-http2) on this network.");
        } else {
            println!("  quic works to other hosts but every warp range stayed silent,");
            println!("  so these ranges really are filtered here.");
            if !tcp_only.is_empty() {
                println!("  the tcp-only ranges above can still carry masque over http/2.");
            }
        }
        println!();
    }

    #[test]
    fn every_masque_prefix_and_seed_parses() {
        for entry in MASQUE_CIDRS_V4 {
            let (addr, bits) = entry.split_once('/').expect("cidr");
            assert!(addr.parse::<Ipv4Addr>().is_ok(), "{entry}");
            assert!(bits.parse::<u8>().is_ok(), "{entry}");
        }
        for entry in MASQUE_CIDRS_V6 {
            let (addr, bits) = entry.split_once('/').expect("cidr");
            assert!(addr.parse::<Ipv6Addr>().is_ok(), "{entry}");
            assert!(bits.parse::<u8>().is_ok(), "{entry}");
        }
        for seed in MASQUE_SEEDS {
            assert!(seed.parse::<Ipv4Addr>().is_ok(), "{seed}");
        }
        for seed in MASQUE_SEEDS_V6 {
            assert!(seed.parse::<Ipv6Addr>().is_ok(), "{seed}");
        }
    }
}
